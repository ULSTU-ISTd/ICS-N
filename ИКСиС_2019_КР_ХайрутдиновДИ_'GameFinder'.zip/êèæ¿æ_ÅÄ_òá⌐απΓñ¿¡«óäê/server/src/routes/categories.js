import { Router } from 'express';
import mongoose from 'mongoose';

const router = Router();

router.get('/', async ({ context: { models } }, res) => {
  try {
    const categories = await models.Category.find({}, { name: 1 });

    return res.status(200).json({ data: { categories }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.get('/:categoryId', async (req, res) => {
  try {
    const {
      context: { models },
      params: { categoryId }
    } = req;

    const category = await models.Category.findOne({
      _id: categoryId
    }).populate({
      path: 'games'
    });

    return res.status(200).json({ data: { category }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const {
      body,
      context: { models },
      query: { name }
    } = req;

    const categoryId = new mongoose.Types.ObjectId();

    const category = new models.Category({
      _id: categoryId,
      name,
      games: []
    });

    category.save();

    return res.status(200).json({ data: 'success', error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

export default router;
