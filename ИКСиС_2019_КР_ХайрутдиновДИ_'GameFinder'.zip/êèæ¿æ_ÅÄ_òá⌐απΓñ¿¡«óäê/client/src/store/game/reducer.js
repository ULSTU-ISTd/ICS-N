import {
  GET_GAMES,
  GET_GAMES_SUCCESS,
  GET_GAMES_FAIL,
  ADD_GAME_SUCCESS,
  UPDATE_GAME_RATING_SUCCESS,
  CHANGE_CURRENT_GAME,
  REMOVE_REVIEW_SUCCESS
} from './constants';
import { ADD_REVIEW_SUCCESS } from 'store/review/constants';

const initialState = {
  games: [],
  currentGame: {}
};

const handlers = {
  [GET_GAMES]: state => ({ ...state }),
  [GET_GAMES_SUCCESS]: (state, { games }) => ({ ...state, games }),
  [GET_GAMES_FAIL]: state => ({ ...state }),
  [ADD_GAME_SUCCESS]: (state, { game }) => ({
    ...state,
    games: [...state.games, game]
  }),
  [CHANGE_CURRENT_GAME]: (state, { gameId }) => ({
    ...state,
    currentGame: state.games.find(game => game._id === gameId)
  }),
  [ADD_REVIEW_SUCCESS]: (state, { review }) => {
    const updatedCurrentGame = { ...state.currentGame };

    updatedCurrentGame.reviews.push(review);

    return { ...state, currentGame: updatedCurrentGame };
  },
  [UPDATE_GAME_RATING_SUCCESS]: (state, { payload: { gameId, direction } }) => {
    const updateCurrentGame = { ...state.currentGame };

    if (direction === 'up') {
      updateCurrentGame.thumbUp += 1;
    } else {
      updateCurrentGame.thumbDown += 1;
    }
    
    updateCurrentGame.disableRating = true;
    
    return { ...state, currentGame: updateCurrentGame };
  },
  [REMOVE_REVIEW_SUCCESS]: (state, { payload: { reviewId } }) => {
    const updateCurrentGame = { ...state.currentGame };

    updateCurrentGame.reviews = updateCurrentGame.reviews.filter(review => {
      return review._id !== reviewId;
    });

    return { ...state, currentGame: updateCurrentGame };
  }
};

const game = (state = initialState, action) => {
  const handler = handlers[action.type];

  if (handler) {
    return handler(state, action);
  }
  return state;
};

export default game;
