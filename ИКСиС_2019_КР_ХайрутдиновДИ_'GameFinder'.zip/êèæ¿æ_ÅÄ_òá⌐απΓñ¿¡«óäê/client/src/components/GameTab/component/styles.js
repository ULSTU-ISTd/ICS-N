const styles = () => ({
  gameTab: {
    width: 400,
    maxHeight: 230,
    position: 'relative',
    margin: '0px 15px 15px 15px',
  },
  gameButton: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)'
  },
  gameTabImage: {
    height: '100%',
    width: '100%',
    borderRadius: 5
  }
});

export default styles;
