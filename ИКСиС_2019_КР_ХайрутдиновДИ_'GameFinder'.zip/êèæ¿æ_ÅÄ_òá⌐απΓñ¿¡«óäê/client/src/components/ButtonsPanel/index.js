import ButtonsPanel from './component/ButtonsPanel';

export default ButtonsPanel;
