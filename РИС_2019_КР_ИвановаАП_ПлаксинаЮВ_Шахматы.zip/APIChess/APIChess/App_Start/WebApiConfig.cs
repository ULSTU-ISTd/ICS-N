﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace APIChess
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            //отображение в json формате
            var json = config.Formatters.JsonFormatter;
            json.SerializerSettings.PreserveReferencesHandling = Newtonsoft.Json.PreserveReferencesHandling.Objects;
            config.Formatters.Remove(config.Formatters.XmlFormatter);

            // Конфигурация и службы веб-API

            // Маршруты веб-API
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                //routeTemplate: "api/{controller}/{id}/{move}",
                routeTemplate: "api/{controller}/{color}/{id}/{move}",
                defaults: new
                {
                    id = RouteParameter.Optional,
                    move = RouteParameter.Optional,//необязательный
                    color = RouteParameter.Optional
                }
            );
        }
    }
}
