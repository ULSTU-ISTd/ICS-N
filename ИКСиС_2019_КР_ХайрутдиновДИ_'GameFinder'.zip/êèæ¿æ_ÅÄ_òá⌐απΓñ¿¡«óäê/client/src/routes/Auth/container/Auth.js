import { connect } from 'react-redux';

import { getUserId } from 'store/user/selectors';
import { login, register } from 'store/user/actions';

import Auth from '../component/Auth';

const mapStateToProps = ({ user }) => ({
  userId: getUserId(user)
});

const mapDispatchToProps = dispatch => ({
  login: (userLogin, userPassword) => dispatch(login(userLogin, userPassword)),
  register: (userLogin, userPassword) => dispatch(register(userLogin, userPassword))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Auth);
