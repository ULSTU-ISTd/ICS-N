import { connect } from 'react-redux';

import { addGame } from 'store/game/actions';

import UploadForm from '../component/UploadForm';

const mapDispatchToProps = {
  addGame
};

export default connect(
  null,
  mapDispatchToProps
)(UploadForm);
