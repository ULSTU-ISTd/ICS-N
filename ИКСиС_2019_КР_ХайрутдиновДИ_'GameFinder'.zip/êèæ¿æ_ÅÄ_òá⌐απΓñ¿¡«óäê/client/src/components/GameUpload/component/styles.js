import { LIGHT_GREEN } from 'styles/colors';

const styles = () => ({
  overlay: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    position: 'fixed',
    top: 0,
    left: 0,
    height: '100vh',
    width: '100vw',
    background: 'rgba(0, 0, 0, .7)',
    zIndex: 1000
  },
  overlayCloser: {
    position: 'absolute',
    top: 70,
    right: 15,
    height: 40,
    width: 40,
    fill: LIGHT_GREEN,
    cursor: 'pointer',
  }
});

export default styles;
