import React from 'react';

import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Divider from '@material-ui/core/Divider';

import RemoveCircle from '@material-ui/icons/RemoveCircle';

import styles from './styles.js';

const Review = ({ classes, review, author, gameName, removeReview }) => {
  const { title, review: userReview, uploadTime } = review;
  const isUserAdmin = localStorage.getItem('admin');

  return (
    <>
      <Paper className={classes.reviewWrap}>
        <Grid container direction="row">
          <Grid item xs={4}>
            <Typography variant="h6">Игра:</Typography>
            <Typography variant="h6">{gameName}</Typography>
          </Grid>
          <Grid item xs={1} />
          <Grid item xs={2}>
            <Typography variant="h6">Дата:</Typography>
            <Typography variant="h6">
              {new Date(uploadTime).toLocaleDateString()}
            </Typography>
          </Grid>
          <Grid item xs={1} />
          <Grid item xs={4}>
            <Typography variant="h6">Автор:</Typography>
            <Typography variant="h6">{author}</Typography>
          </Grid>
        </Grid>
        <Divider />
        <Typography variant="h4">{title}</Typography>
        <Typography variant="h6">{userReview}</Typography>
        {isUserAdmin ? (
          <RemoveCircle className={classes.removeIcon} onClick={removeReview} />
        ) : null}
      </Paper>
    </>
  );
};

export default withStyles(styles)(Review);
