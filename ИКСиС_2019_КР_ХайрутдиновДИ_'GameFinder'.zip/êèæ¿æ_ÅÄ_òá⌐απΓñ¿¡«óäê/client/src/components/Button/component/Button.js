import React from 'react';

import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import styles from './styles';

const CustomButton = props => {
  const { classes, onClick, isActive } = props;
  const activeClass = isActive ? classes.activeButton : null;

  return (
    <Button onClick={onClick} className={`${classes.button} ${activeClass}`}>
      {props.children}
    </Button>
  );
};

export default withStyles(styles)(CustomButton);
