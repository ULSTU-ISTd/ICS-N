<?
$Time = date('i');
if($Time >= 30) $Time -= 30;
if($Time >= 15) $Time -= 15;
if($Time < 10) $Status = true;
if($Time >= 10) $Status = false;

//maximum - curr_min - curr_sec
if($Status) {
  $Timer=10*60 - ($Time*60 + date('s'));
} else {
  $Timer=5*60 - ($Time-10)*60 - date('s');
}

$data['time'] = $Timer;
$data['status'] = $Status;
header('Content-Type: application/json');
echo json_encode($data);
