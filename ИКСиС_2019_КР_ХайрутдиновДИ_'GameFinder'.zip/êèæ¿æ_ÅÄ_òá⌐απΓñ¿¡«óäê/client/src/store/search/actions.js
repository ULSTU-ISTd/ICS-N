import apiClient from 'utils/apiClient';
import {
  SEARCH,
  SEARCH_SUCCESS,
  SEARCH_FAIL,
  QUERY_POPULAR_SEARCHES,
  QUERY_POPULAR_SEARCHES_SUCCESS,
  QUERY_POPULAR_SEARCHES_FAIL
} from './constants';

export function search(query) {
  return dispatch => {
    dispatch({ type: SEARCH });

    apiClient.post('search', { query }).then(({ data, error }) => {
      if (error) {
        dispatch({ type: SEARCH_FAIL });
      }

      const { games } = data;
      dispatch({ type: SEARCH_SUCCESS, games });
    });
  };
}

export function queryPopularSearches() {
  return dispatch => {
    dispatch({ type: QUERY_POPULAR_SEARCHES });

    apiClient.get('search').then(({ data, error }) => {
      if (error) {
        dispatch({ type: QUERY_POPULAR_SEARCHES_FAIL });
      }

      const { searches } = data;
      dispatch({ type: QUERY_POPULAR_SEARCHES_SUCCESS, searches });
    });
  };
}
