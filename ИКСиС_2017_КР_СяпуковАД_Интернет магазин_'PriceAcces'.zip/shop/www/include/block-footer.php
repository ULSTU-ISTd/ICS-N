<div class="footer">
	<div class="footer-top-info">
		<div class="footer-info-block">
			<ul>
				<li><a href="">FAQ</a></li>
				<li><a href="">О нас</a></li>
				<li><a href="">Доставка</a></li>
				<li><a href="">Как заказать?</a></li>
				<li><a href="">Правила пользования</a></li>
				<li><a href="">Наши магазины</a></li>
			</ul>
		</div>
		<div class="footer-info-block">
			<ul>
				<li><a href="">FAQ</a></li>
				<li><a href="">О нас</a></li>
				<li><a href="">Доставка</a></li>
				<li><a href="">Как заказать?</a></li>
				<li><a href="">Правила пользования</a></li>
				<li><a href="">Наши магазины</a></li>
			</ul>
		</div>
	</div>
</div>

<div class="copyright">
	<div class="block-copyright">
	Copyrighting by <a href="">Alexander Syapukov</a>
	</div>
</div>