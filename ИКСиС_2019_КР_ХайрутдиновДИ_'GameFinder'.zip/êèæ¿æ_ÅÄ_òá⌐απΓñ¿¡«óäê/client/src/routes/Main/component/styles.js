const styles = () => ({
  buttons: {
    position: 'fixed',
    bottom: 15,
    right: 15,
  }
});

export default styles;