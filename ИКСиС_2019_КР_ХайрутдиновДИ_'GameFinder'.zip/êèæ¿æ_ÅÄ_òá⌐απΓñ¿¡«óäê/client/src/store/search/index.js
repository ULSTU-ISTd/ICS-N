import searches from './reducer';

export default searches;
