/* */ 
module.exports = { "default": require("core-js/library/fn/object/is"), __esModule: true };