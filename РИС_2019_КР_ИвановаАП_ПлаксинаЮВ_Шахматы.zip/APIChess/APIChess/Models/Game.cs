namespace APIChess.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Game
    {
        public int ID { get; set; }

        [StringLength(255)]
        public string FEN { get; set; }

        [StringLength(4)]
        public string Status { get; set; }

        [StringLength(10)]
        public string LastMove { get; set; }

        public bool Shah { get; set; }

        [StringLength(50)]
        public string Winner { get; set; }
    }
}
