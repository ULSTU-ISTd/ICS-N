export const getCategories = state => state.categories;
export const getCategoryGames = state => state.categoryGames;
