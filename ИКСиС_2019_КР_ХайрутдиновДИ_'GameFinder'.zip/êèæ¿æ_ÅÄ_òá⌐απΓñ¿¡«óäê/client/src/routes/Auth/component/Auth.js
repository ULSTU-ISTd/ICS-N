import React, { Component } from 'react';
import Recaptcha from 'react-recaptcha';

import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Input from '@material-ui/core/Input';
import { withStyles } from '@material-ui/core/styles';

import Button from 'components/Button';

import { isUserIdPresence, setUserId } from 'helpers/localStorage';

import styles from './styles';

class Auth extends Component {
  constructor(props) {
    super(props);

    this.state = {
      currentForm: 'login',
      login: '',
      password: ''
    };

    this.recaptcha = React.createRef();

    this.handleFormChange = this.handleFormChange.bind(this);
    this.handleLoginInput = this.handleLoginInput.bind(this);
    this.handlePasswordInput = this.handlePasswordInput.bind(this);
    this.handleFormSubmit = this.handleFormSubmit.bind(this);
    this.verifyCallback = this.verifyCallback.bind(this);
  }

  componentDidMount() {
    if (isUserIdPresence()) {
      const { history } = this.props;

      history.push('/profile');
      return;
    }
  }

  componentWillReceiveProps({ userId }) {
    if (!userId) {
      return;
    }
    const { history } = this.props;

    setUserId(userId);
    history.push('/profile');
  }

  handleFormChange(event, value) {
    this.setState({ currentForm: value });
  }

  handleLoginInput({ target: { value } }) {
    this.setState({ login: value });
  }

  handlePasswordInput({ target: { value } }) {
    this.setState({ password: value });
  }

  handleFormSubmit() {
    if (!this.userVerified) {
      return;
    }

    const { login, register } = this.props;
    const { currentForm, login: userLogin, password } = this.state;

    if (currentForm === 'login') {
      login(userLogin, password);
    }

    if (currentForm === 'register') {
      register(userLogin, password);
    }
  }

  verifyCallback() {
    console.log('callback');
    this.userVerified = true;
  }

  render() {
    const { classes } = this.props;
    const { currentForm, login, password } = this.state;

    return (
      <Paper className={classes.authWrap}>
        <Tabs
          className={classes.tabHeaders}
          value={currentForm}
          onChange={this.handleFormChange}
        >
          <Tab value="login" label="Войти" />
          <Tab value="register" label="Регистрация" />
        </Tabs>
        <form className={classes.authForm}>
          <Input
            type="text"
            placeholder="Логин"
            value={login}
            className={classes.authFormInput}
            onInput={this.handleLoginInput}
          />
          <Input
            type="password"
            placeholder="Пароль"
            value={password}
            className={classes.authFormInput}
            onInput={this.handlePasswordInput}
          />
          <Button onClick={this.handleFormSubmit}>
            {currentForm === 'login' ? 'Войти' : 'Зарегестрироваться'}
          </Button>
          <Recaptcha
            sitekey="6LedjacUAAAAAFR5KBJ70WKr1Z5OV2MCakWYx_62"
            render="explicit"
            verifyCallback={this.verifyCallback}
          />
        </form>
      </Paper>
    );
  }
}

export default withStyles(styles)(Auth);
