﻿<?
require_once('../../php/bd.php');
$message = $_POST['message'];
$UserID=0;
$mysqli->query('INSERT INTO `Messages` (`FromID`, `SMS`) VALUES (1,"'.$message.'")');
echo 'Сообщение отправлено!';
