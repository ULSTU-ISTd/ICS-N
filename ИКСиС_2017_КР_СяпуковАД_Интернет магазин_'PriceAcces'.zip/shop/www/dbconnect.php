<?php
    $server = "localhost"; /* имя хоста (уточняется у провайдера), если работаем на локльном сервере то указываем localhost */
    $database = "magaz"; /* Имя базы данных, которую создали */
    $username = "root"; /* Имя пользователя БД */
    $password = ""; /* Пароль пользователя, если у пользователя нет пароля то, оставляем пустым */
 
    // Подключение к серверу MySQL
    $connect = mysql_connect($server,$username,$password) or die ( mysql_error() );
     
    // Выбираем базу данных к которой хотим подключится
    mysql_select_db($database, $connect);
?>