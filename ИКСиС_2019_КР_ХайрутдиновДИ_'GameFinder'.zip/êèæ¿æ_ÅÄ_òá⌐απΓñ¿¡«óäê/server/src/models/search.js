import { Schema, model } from 'mongoose';

const searchSchema = Schema({
  _id: Schema.Types.ObjectId,
  query: { type: String, required: true },
  timesSearched: { type: Number, required: true, default: 0 }
});

const Search = model('Search', searchSchema);

export default Search;
