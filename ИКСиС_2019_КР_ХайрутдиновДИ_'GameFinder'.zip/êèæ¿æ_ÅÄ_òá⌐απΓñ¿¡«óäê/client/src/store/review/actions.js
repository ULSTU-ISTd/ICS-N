import apiClient from 'utils/apiClient';
import {
  ADD_REVIEW,
  ADD_REVIEW_SUCCESS,
  ADD_REVIEW_FAIL
} from 'store/review/constants';

function getFormData(dataObject) {
  const formData = new FormData();

  Object.keys(dataObject).forEach(key => {
    formData.append(key, dataObject[key]);
  });

  return formData;
}

export function addReview(authorId, title, review, gameId) {
  return dispatch => {
    dispatch({ type: ADD_REVIEW });

    apiClient
      .post(
        `reviews?authorId=${authorId}&title=${title}&gameId=${gameId}&userReview=${review}`,
      )
      .then(({ data, error }) => {
        if (error) {
          dispatch({ type: ADD_REVIEW_FAIL });
          return;
        }

        const { returnReview } = data;
        dispatch({ type: ADD_REVIEW_SUCCESS, review: returnReview });
      });
  };
}
