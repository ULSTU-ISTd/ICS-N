import { Schema, model } from 'mongoose';

const userSchema = Schema({
  _id: Schema.Types.ObjectId,
  login: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  reviews: [{ type: Schema.Types.ObjectId, ref: 'Review' }]
});

const User = model('User', userSchema);

export default User;
