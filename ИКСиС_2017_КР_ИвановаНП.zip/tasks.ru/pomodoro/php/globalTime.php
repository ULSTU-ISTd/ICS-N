<?
$Time = date('i');
for ($i=12; $i > 1; $i--) {
  if($Time >= 5*$i) {
    $Time -= 5*$i;
    break;
  }
}
if($Time < 4) $Status = true;
if($Time >= 4) $Status = false;

//maximum - curr_min - curr_sec
if($Status) {
  $Timer=4*60 - ($Time*60 + date('s'));
} else {
  $Timer=1*60 - ($Time-4)*60 - date('s');
}

$data['time'] = $Timer;
$data['status'] = $Status;
header('Content-Type: application/json');
echo json_encode($data);
