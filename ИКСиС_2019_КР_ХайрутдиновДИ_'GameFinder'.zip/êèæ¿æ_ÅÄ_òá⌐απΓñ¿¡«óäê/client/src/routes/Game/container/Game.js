import { connect } from 'react-redux';

import { getCurrentGame } from 'store/game/selectors';
import { updateGameRating, changeCurrentGame, removeReview } from 'store/game/actions';

import Game from '../component/Game';

const mapStateToProps = ({ game }) => ({
  game: getCurrentGame(game)
});

const mapDispatchToProps = {
  updateGameRating,
  changeCurrentGame,
  removeReview
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Game);
