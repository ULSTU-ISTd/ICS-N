import postcss from 'rollup-plugin-postcss';
import resolve from 'rollup-plugin-node-resolve';
import babel from 'rollup-plugin-babel';
import commonjs from 'rollup-plugin-commonjs';
import replace from 'rollup-plugin-replace';
import progress from 'rollup-plugin-progress';
import serve from 'rollup-plugin-serve'
import livereload from 'rollup-plugin-livereload'
import alias from 'rollup-plugin-alias';
import image from 'rollup-plugin-img';
import json from 'rollup-plugin-json';
import builtins from 'rollup-plugin-node-builtins';
import globals from 'rollup-plugin-node-globals';
import { sizeSnapshot } from 'rollup-plugin-size-snapshot';

function getRollupConfig() {
  const config = {
    input: 'src/index.js',
    cache: null,
    output: {
      file: 'dist/bundle.js',
      format: 'iife'
    },
    plugins: [
      json(),
      progress({
        clearline: false
      }),
      sizeSnapshot(),
      postcss({
        extensions: ['.scss'],
        autoModules: true
      }),
      alias({
        assets: __dirname + '/src/assets',
        components: __dirname + '/src/components',
        containers: __dirname + '/src/containers',
        helpers: __dirname + '/src/helpers',
        routes: __dirname + '/src/routes',
        styles: __dirname + '/src/styles',
        store: __dirname + '/src/store',
        utils: __dirname + '/src/utils',
        resolve: ['.js', '/index.js', '.scss', '.css']
      }),
      image({
        output: `dist/images`,
        extensions: /\.(png|jpg|jpeg|gif|svg)$/,
        limit: 8192,
        exclude: 'node_modules/**'
      }),
      replace({
        'process.env.NODE_ENV': JSON.stringify('development')
      }),
      resolve({
        mainFields: ['main', 'module', 'jsnext'],
        dedupe: ['react', 'react-dom']
      }),
      commonjs({
        include: 'node_modules/**',
        browser: true,
        sourceMap: false,
        namedExports: {
          'node_modules/react/index.js': [
            'Children',
            'Component',
            'PropTypes',
            'createElement',
            'useMemo',
            'useContext',
            'useEffect',
            'useLayoutEffect',
            'useRef',
            'useReducer'
          ],
          'node_modules/@material-ui/core/styles/index.js': ['withStyles'],
          'node_modules/buffer/index.js': ['isBuffer'],
          'node_modules/process/index.js': ['nextTick'],
          'node_modules/events/events.js': ['EventEmitter'],
          'node_modules/react-recaptcha/dist/react-recaptcha.js': ['Recaptcha'],
          'node_modules/react-dom/index.js': ['unstable_batchedUpdates'],
          'node_modules/react-is/index.js': [
            'isValidElementType',
            'isContextConsumer'
          ]
        }
      }),
      globals(),
      builtins(),
      babel({
        exclude: 'node_modules/**'
      }),
      serve({
        open: true,
        contentBase: 'dist',
        historyApiFallback: true,
        host: 'localhost',
        port: 3000,
      })
    ]
  };

  return config;
}

const rollupConfig = getRollupConfig();

export default rollupConfig;
