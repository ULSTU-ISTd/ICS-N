import React from 'react';
import { Link } from 'react-router-dom';

import AppBar from '@material-ui/core/AppBar';
import Button from '@material-ui/core/Button';
import { withStyles } from '@material-ui/core/styles';

import UserAvatar from 'components/UserAvatar';
import styles from './styles';

const AppHeader = ({ classes }) => (
  <AppBar className={classes.header}>
    <nav className={classes.nav}>
      <Button
        className={classes.navButton}
        component={Link}
        to={{ pathname: '/' }}
      >
        Главная
      </Button>
      <Button
        className={classes.navButton}
        component={Link}
        to={{ pathname: '/categories' }}
      >
        Жанры
      </Button>
      <Button
        className={classes.navButton}
        component={Link}
        to={{ pathname: '/searches' }}
      >
        Поиски
      </Button>
    </nav>
    <UserAvatar />
  </AppBar>
);

export default withStyles(styles)(AppHeader);
