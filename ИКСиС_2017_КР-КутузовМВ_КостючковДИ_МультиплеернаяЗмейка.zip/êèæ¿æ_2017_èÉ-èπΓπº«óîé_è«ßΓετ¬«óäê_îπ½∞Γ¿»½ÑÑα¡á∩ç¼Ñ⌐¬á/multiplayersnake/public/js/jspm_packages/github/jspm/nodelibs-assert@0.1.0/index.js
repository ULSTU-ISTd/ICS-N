/* */ 
module.exports = System._nodeRequire ? System._nodeRequire('assert') : require('assert');