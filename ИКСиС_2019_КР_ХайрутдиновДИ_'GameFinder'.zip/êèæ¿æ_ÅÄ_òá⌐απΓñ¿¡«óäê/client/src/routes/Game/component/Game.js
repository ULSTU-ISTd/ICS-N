import React from 'react';

import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Divider from '@material-ui/core/Divider';

import ThumbUp from '@material-ui/icons/ThumbUp';
import ThumbDown from '@material-ui/icons/ThumbDown';

import ReviewForm from 'components/ReviewForm';
import Review from 'components/Review';

import tempImage from '../../../assets/temp.jpg';

import styles from './styles';

class Game extends React.Component {
  componentDidMount() {
    const {
      changeCurrentGame,
      match: { params }
    } = this.props;

    changeCurrentGame(params.gameId);
  }

  render() {
    const { game, classes, updateGameRating, removeReview } = this.props;

    return (
      <div className={classes.gameContainer}>
        <Grid container>
          <Grid item xs={5} className={classes.imageWrap}>
            <img src={game.url || tempImage} className={classes.image} />
          </Grid>
          <Grid item xs={1} />
          <Grid item xs={6}>
            <Typography variant="h6">Название</Typography>
            <Typography variant="h4">{game.name}</Typography>
            <Divider />
            <Typography variant="h6">Описание</Typography>
            <Typography variant="h4">{game.description}</Typography>
            <Divider />
            <Typography variant="h6">Издатель</Typography>
            <Typography variant="h4">{game.publisher}</Typography>
            <Divider />
            <Typography variant="h6">Rating</Typography>
            <Grid container direction="row">
              <Grid container direction="row">
                <Grid container>
                  <Typography variant="h4">{game.thumbUp}</Typography>
                  <ThumbUp
                    onClick={() =>
                      !game.disableRating
                        ? updateGameRating(game._id, 'up')
                        : null
                    }
                  />
                </Grid>
                <Grid container>
                  <Typography variant="h4">{game.thumbDown}</Typography>
                  <ThumbDown
                    onClick={() =>
                      !game.disableRating
                        ? updateGameRating(game._id, 'down')
                        : null
                    }
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Divider />
        <Grid container>
          <Grid container direction="row" justify="center">
            <Typography variant="h4">Reviews</Typography>
          </Grid>
          <Grid item xs={7}>
            {game.reviews && game.reviews.length > 0
              ? game.reviews.map(review => (
                  <Review
                    key={review._id}
                    gameName={game.name}
                    review={review}
                    author={review.author.login}
                    removeReview={() => removeReview(review._id)}
                  />
                ))
              : 'There is no reviews'}
          </Grid>
          <Grid item xs={5}>
            <ReviewForm gameId={game._id} />
          </Grid>
        </Grid>
      </div>
    );
  }
}

export default withStyles(styles)(Game);
