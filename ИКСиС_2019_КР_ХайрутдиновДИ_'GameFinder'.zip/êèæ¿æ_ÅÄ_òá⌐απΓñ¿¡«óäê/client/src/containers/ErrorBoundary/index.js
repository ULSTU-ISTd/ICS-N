import ErrorBoundary from './component/ErrorBoundary';

export default ErrorBoundary;