<?php

	include("functions/functions.php");
	session_start();
	include("include/db_connect.php");
	include("include/auth_cookie.php");
	
	$id = clear_string($_GET["id"]); 
	

    
  If ($id != $_SESSION['countid'])
{
$querycount = mysql_query("SELECT count FROM table_products WHERE product_id='$id'",$link);
$resultcount = mysql_fetch_array($querycount); 
 
$newcount = $resultcount["count"] + 1;
 
$update = mysql_query ("UPDATE table_products SET count='$newcount' WHERE product_id='$id'",$link);  
}
 
$_SESSION['countid'] = $id; 
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Интернет-магазин</title>
<link rel="stylesheet" href="/css/style.css">

    <script type="text/javascript" src="/js/jquery-1.8.2.min.js"></script> 
    <script type="text/javascript" src="/js/jcarousellite_1.0.1.js"></script> 
    <script type="text/javascript" src="/js/shop-script.js"></script>
    <script type="text/javascript" src="/js/jquery.cookie.min.js"></script>

    
    <script type="text/javascript" src="/js/jquery.form.js"></script>
    <script type="text/javascript" src="/js/jquery.validate.js"></script>  
    <script type="text/javascript" src="/js/TextChange.js"></script> 
	
	   <link rel="stylesheet" type="text/css" href="/fancybox/jquery.fancybox.css" />
    <script type="text/javascript" src="/fancybox/jquery.fancybox.js"></script>
    <script type="text/javascript" src="/js/jTabs.js"></script>
	<script type="text/javascript">
$(document).ready(function(){
  
    $("ul.tabs").jTabs({content: ".tabs_content", animate: true, effect:"fade"}); 
    $(".image-modal").fancybox(); 
    $(".send-review").fancybox();
     
}); 
</script> 
</head>
<body>
<?php
	include("/include/block-header.php");
?>
	
	<div class="block-center">
		<div class="centercont">
			<?php
				include("/include/menu-left.php");
			?>
			<div class="block-content">
<?php

$result = mysql_query("SELECT * FROM table_products WHERE product_id='$id'",$link);
If (mysql_num_rows($result) > 0)
{
$row = mysql_fetch_array($result);
do
{   
if  (strlen($row["image"]) > 0 && file_exists("./product_img/".$row["image"]))
{
$img_path = './product_img/'.$row["image"];
$max_width = 300; 
$max_height = 300; 
 list($width, $height) = getimagesize($img_path); 
$ratioh = $max_height/$height; 
$ratiow = $max_width/$width; 
$ratio = min($ratioh, $ratiow); 
 
$width = intval($ratio*$width); 
$height = intval($ratio*$height);    
}else
{
$img_path = "/img/noimages.jpeg";
$width = 250;
$height = 400;
} 
 
 
echo  '
 
						<div class="block-view-product">
							<div class="view-product-img">
								<img src="'.$img_path.'" class="product-img-center" width="'.$width.'" height="'.$height.'" />
							</div>
							<div class="block-view-info">
								<p class="title-view-product">'.$row["title"].'</p>
								<p class="desc-view-product">'.$row["description"].'</p>
								<div class="view-price-cart">
									<p class="price-view">'.group_numerals($row["price"]).'<a class="price_valiut">р.</a></p><a tid="'.$row["product_id"].'" class="cart-button"><img src="/img/carts.png" width="110" height="35"></a>
								</div>
							</div>
						</div>
 
';
 
    
}
 while ($row = mysql_fetch_array($result));
 
 $result = mysql_query("SELECT * FROM uploads_images WHERE product_id='$id'",$link);
If (mysql_num_rows($result) > 0)
{
$row = mysql_fetch_array($result);
echo '<div id="block-img-slide">
      <ul>';
do
{
     
$img_path = './product_img/'.$row["image"];
$max_width = 70; 
$max_height = 70; 
 list($width, $height) = getimagesize($img_path); 
$ratioh = $max_height/$height; 
$ratiow = $max_width/$width; 
$ratio = min($ratioh, $ratiow); 
 
$width = intval($ratio*$width); 
$height = intval($ratio*$height);    
     
     
echo '
<li>
<a class="image-modal" href="#image'.$row["id"].'"><img src="'.$img_path.'" width="'.$width.'" height="'.$height.'" /></a>
</li>
<a style="display:none;" class="image-modal" rel="group" id="image'.$row["id"].'" ><img  src="./product_img/'.$row["image"].'" /></a>
';
}
 while ($row = mysql_fetch_array($result));
 echo '
 </ul>
 </div>    
        ';
}
 
 
}
     
?>
			
			</div>
		</div>
	</div>
</div>

	
	
<?php
	include("/include/block-footer.php");
?>
</body>
</html>