<?
require_once ('../../php/bd.php');
$data['msg'] = 'zero';

$count =  $mysqli->query("SELECT Type FROM Tasks WHERE ID=". $_GET['id'])->fetch_row()[0];
if($count != null) {//данные из формы 'delete' получены
//id did exist


  if($_GET['delete'] == "true") {
    //$sqlquery="DELETE FROM Tasks WHERE ID=".$_GET['id'];
    //$mysqli->query($sqlquery);
    $data['msg'] = 'задача удалена';
    $sqlquery=$mysqli->query("UPDATE Tasks SET Type = 127	WHERE ID=". $_GET['id']);
  } else {
    $data['msg'] = 'задача не удалена, а архивирована';
    $count= (int)$count+1;
    $sqlquery=$mysqli->query("UPDATE Tasks SET Type = ".$count."	WHERE ID=". $_GET['id']);
  }




} else $data['msg'] = 'Такой задачи не существует!';
//$DATA[]=$_POST;
//$DATA[]=$_GET;
header('Content-Type: application/json');
echo json_encode($data);
