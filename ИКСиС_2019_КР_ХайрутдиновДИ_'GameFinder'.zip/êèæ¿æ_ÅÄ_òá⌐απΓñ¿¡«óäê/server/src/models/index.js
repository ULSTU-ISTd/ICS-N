import Review from './review';
import Category from './category';
import User from './user';
import Search from './search';
import Game from './game';

export default {
  Review,
  Category,
  User,
  Search,
  Game
};
