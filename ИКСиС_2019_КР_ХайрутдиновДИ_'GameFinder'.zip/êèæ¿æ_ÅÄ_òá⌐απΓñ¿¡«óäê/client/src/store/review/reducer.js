import {
  GET_REVIEWS,
  GET_REVIEWS_SUCCESS,
  GET_REVIEWS_FAIL,
  UPDATE_REVIEW_RATING_SUCCESS
} from './constants';

const initialState = {
  reviews: []
};

const handlers = {
  [GET_REVIEWS]: state => ({ ...state }),
  [GET_REVIEWS_SUCCESS]: (state, { reviews }) => ({ ...state, reviews }),
  [GET_REVIEWS_FAIL]: state => ({ ...state }),
  [UPDATE_REVIEW_RATING_SUCCESS]: (
    state,
    { payload: { reviewId, updateValue } }
  ) => {
    const review = state.reviews.find(review => review._id === reviewId);
    const reviewIndex = state.reviews.findIndex(review => review._id === reviewId);
    const reviews = state.reviews.filter(review => review._id !== reviewId);

    review.rating += updateValue;
    reviews.splice(reviewIndex, 0, review);

    return { ...state, reviews };
  }
};

const review = (state = initialState, action) => {
  const handler = handlers[action.type];

  if (handler) {
    return handler(state, action);
  }
  return state;
};

export default review;
