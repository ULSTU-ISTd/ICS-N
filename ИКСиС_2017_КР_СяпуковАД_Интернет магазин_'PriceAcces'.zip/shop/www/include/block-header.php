﻿<div class="header">

		<div class="headline">
			<center><img src="/img/log.png" width="240px" height="auto"></center>
		</div>
		<div class="cotegory">
		<div class="block-center-top">
			<div class="auth-top-left">
			
				<?php
				
					if ($_SESSION['auth'] == 'yes_auth')
					{
						echo '<p class="auth-user-info">Здравствуйте, '.$_SESSION['auth_name'].'!</p>';
					} else
					{
						echo ' 
								<a class="top-auth">Вход</a>
								<span> | </span>
								<a href="registration.php">Регистрация</a> 
							';
					}
				
				?>
				
			<div class="block-top-auth">
				<div class="corner"></div>
				
				<form method="post">
					<ul class="input-email-pass">
					<h3>Вход</h3>
					<p id="message-auth">Неверный Логин и(или) Пароль</p>
					
					<li><input type="text" id="auth_login" placeholder="Логин или E-mail"></li>
					<li><input type="password" id="auth_pass" placeholder="Пароль"></li>
					
					<ul class="list-auth">
						<li><input type="checkbox" name="rememberme" id="rememberme" /><label for="rememberme">Запомнить меня</label></li>
						<li><a class="remindpass" href="#">Забыли пароль?</a></li>
					</ul>
					</ul>
				
					<p align="right" id="button-auth"><a>Вход</a></p>
					<p align="right" class="auth-loading"><img src="/img/loader.gif"></p>
				</form>
			</div>
			<div class="block-user">
						<div class="corner2"></div>
						<ul class="center-profile">
							<li><a href="profile.php"><img src="/img/profile.png" width="16px" height="16px" /> Мой профиль</a></li>
							<li><a id="logout"><img src="/img/logout.png" width="15px" height="15px" /> Выход</a></li>
						</ul>
			</div>
					</div>
			<ul class="menuright">
				<a href="index.php"><li>Главная</li></a>
				<a href=""><li>Акции</li></a>
				<a href=""><li>Новинки</li></a>
				<a href=""><li>Распродажа</li></a>
			</ul>
			<div class="cart-top-right">
			<img src="/img/cart-ico.png" width="35px" height="30px" /><p class="block-basket"><a href="cart.php?action=oneclick" ></a></p>
			</div>
			</div>
		</div>
</div>