/* */ 
module.exports = { "default": require("core-js/library/fn/math/fround"), __esModule: true };