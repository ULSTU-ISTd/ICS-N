export const selectGames = state => state.games;
export const getCurrentGame = state => state.currentGame;
