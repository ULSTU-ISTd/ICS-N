const USER_ID_KEY = 'userId';

export function setUserId(userId) {
  localStorage.setItem(USER_ID_KEY, userId);
}

export function removeUserId(userId) {
  localStorage.removeItem(USER_ID_KEY);
}

export function getUserId() {
  const userId = localStorage.getItem(USER_ID_KEY);

  return userId;
}

export function isUserIdPresence() {
  const userId = localStorage.getItem(USER_ID_KEY);

  return !!userId;
}
