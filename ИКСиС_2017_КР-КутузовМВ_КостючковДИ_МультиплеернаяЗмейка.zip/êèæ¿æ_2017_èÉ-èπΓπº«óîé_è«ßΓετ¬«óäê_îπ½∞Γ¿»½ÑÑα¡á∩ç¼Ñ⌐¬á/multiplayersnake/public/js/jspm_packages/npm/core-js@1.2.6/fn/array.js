/* */ 
module.exports = require('./array/index');
