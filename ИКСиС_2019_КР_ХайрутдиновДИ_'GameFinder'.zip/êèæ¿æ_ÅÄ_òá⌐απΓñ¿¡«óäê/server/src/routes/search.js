import { Router } from 'express';

const router = Router();

router.get('/', async ({ context: { models } }, res) => {
  try {
    const searches = await models.Search.find({})
      .sort({ timesSearched: -1 })
      .limit(10);

    return res.status(200).json({ data: { searches }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const {
      context: { models },
      body: { query }
    } = req;

    const games = await models.Game.find({
      name: query
    });

    await models.Search.updateOne(
      { query },
      { $inc: { timesSearched: 1 } },
      { upsert: true }
    );

    return res.status(200).json({ data: { games }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

export default router;
