export const getLastSearchGames = state => state.lastSearchGames;
export const getSearches = state => state.searches;
