/* */ 
module.exports = { "default": require("core-js/library/fn/object/get-own-property-symbols"), __esModule: true };