import { Schema, model } from 'mongoose';

const categorySchema = Schema({
  _id: Schema.Types.ObjectId,
  name: { type: String, required: true },
  games: [{ type: [Schema.Types.ObjectId], required: true, ref: 'Game' }]
});

const Category = model('Category', categorySchema);

export default Category;
