import { Router } from 'express';
import axios from 'axios';

const router = Router();

async function asyncForEach(array, callback) {
  for (let index = 0; index < array.length; index++) {
    await callback(array[index], index, array);
  }
}

let gamesGlobal = [];

router.get('/', async (req, res) => {
  const config = {
    headers: {
      'user-key': 'ab0bf70d2f57e22ae49307465ec85281',
      Accept: 'application/json'
    }
  };

  console.log('request');
  try {
    const gameApiUrl = 'https://api-v3.igdb.com';
    const { data: gamesFromOpenApi } = await axios.post(
      `${gameApiUrl}/games`,
      'fields: name, id; limit: 10;',
      config
    );
    const covers = [];
    const descriptions = [];

    await asyncForEach(gamesFromOpenApi, async game => {
      const cover = await axios.post(
        `${gameApiUrl}/covers`,
        `fields url; where game=${game.id};`,
        config
      );

      const url = cover.data[0] ? cover.data[0].url : null;
      covers.push(url);

      const summary = await axios.post(
        `${gameApiUrl}/games`,
        `fields summary; where id=${game.id};`,
        config
      );

      const description = summary.data[0] ? summary.data[0].summary : null;
      descriptions.push(description);
    });

    gamesFromOpenApi.forEach((game, index) => {
      game.description = descriptions[index];
      game.cover = covers[index];
    });

    console.log('response');
    return res.status(200).json({ data: { games: gamesFromOpenApi }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

export default router;
