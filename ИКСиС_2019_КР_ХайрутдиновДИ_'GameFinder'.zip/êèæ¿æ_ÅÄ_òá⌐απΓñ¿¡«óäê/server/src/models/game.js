import { Schema, model } from 'mongoose';

const gameSchema = Schema({
  _id: Schema.Types.ObjectId,
  name: { type: String, required: true },
  description: { type: String, required: true },
  publisher: { type: String, required: true },
  url: { type: String },
  thumbUp: { type: Number, default: 0 },
  thumbDown: { type: Number, default: 0 },
  category: { type: Schema.Types.ObjectId, ref: 'Category' },
  reviews: [{ type: [Schema.Types.ObjectId], required: true, ref: 'Review' }]
});

const Game = model('Game', gameSchema);

export default Game;
