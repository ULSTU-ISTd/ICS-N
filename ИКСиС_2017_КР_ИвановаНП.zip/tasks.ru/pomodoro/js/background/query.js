function ajaxNotificationButton(arg=false) {
  Ajax.open({
    method: 'GET',
    url: 'http://tasks.ru/pomodoro/php/test.php?delete='+arg+'&id='+ localStorage['Task_ID'],
    dataType: 'json',
    success: function (json) {
      console.log(json);
    }
  });
}
function debounce(f, ms) {
  var state = null;
  var COOLDOWN = 1;
  return function() {
    if (state) return;
    f.apply(this, arguments);
    state = COOLDOWN;
    setTimeout(function() { state = null }, ms);
  }
}
//------------------favicon count-----------------------------
function updateBadge(options) {
  let text = options.text;
  let badgeTitle = 'Tomato chat';
  let color;
  if(localStorage['Type'] == 'alarm')//-------------------------------------ТИП и ЦВЕТ
    color='blue';
  else
    color='red';
  chrome.browserAction.setTitle({ title: badgeTitle });
  chrome.browserAction.setBadgeText({ text });
  chrome.browserAction.setBadgeBackgroundColor({ color });
};
function removeBadge() {
  chrome.browserAction.setTitle({ title: '' });
  chrome.browserAction.setBadgeText({ text: '' });
}
function notifct() {
  chrome.notifications.create({
    type: "basic",
    title: "Time to rest",
    message: "Are you completed your task?",
    iconUrl: "img/pomodoro-active.png",
    buttons: [
      {
        title: "YES",
      }, {
        title: "NO",
      }
    ]
  }, function(id) {
    myNotificationID = id;
  });
}
//-------------------------- Будильник/таймер ------------------------------
function createAlarm() {
  Ajax.open({
    method: 'GET',
    url: "http://tasks.ru/pomodoro/php/globalTime.php",
    dataType: 'json',
    success: function (json) {//synchron_time and status
      let Type;
      let Minutes;
      if(json.status) {
        Type = 'alarm_work';
        Minutes = json.time/60;

        //setTimeout(notifct, 1); когда начинается помидорка
        setTimeout(notifct, json.time*1000-5000);//за 5сек до начала перерыва
      } else {
        Type = 'alarm';
        Minutes =json.time/60;
      }
      localStorage['Time']=Minutes*60;
      localStorage['Type']=Type;

      chrome.alarms.get(Type,function(alarm){
        if(typeof alarm === "undefined") {
          chrome.alarms.clear(Type);
          const delayInMinutes = Minutes;// minimum 1
          chrome.alarms.create(Type, {delayInMinutes});
        }
      });
    }
  });
}
function getAlarm() {
  let type = localStorage['Type'];
  chrome.alarms.get(type,function(alarm){
    if(!(typeof alarm === "undefined")) {
      chrome.alarms.get(type, (alarm) => {
        if (alarm) {
          //console.log(new Date(alarm.scheduledTime) - Date.now());
          localStorage['Time'] = Math.round((new Date(alarm.scheduledTime) - Date.now())/1000)
          localStorage['Type'] = type;
        }
      })
    } else {
      return false;
    }
  });
}
