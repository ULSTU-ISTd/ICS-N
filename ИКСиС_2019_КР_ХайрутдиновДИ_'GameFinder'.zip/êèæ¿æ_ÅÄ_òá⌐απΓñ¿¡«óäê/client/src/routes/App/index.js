import App from './component/App';

export default App;
