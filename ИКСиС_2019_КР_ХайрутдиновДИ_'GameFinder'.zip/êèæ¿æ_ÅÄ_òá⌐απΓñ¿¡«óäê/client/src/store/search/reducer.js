import {
  SEARCH,
  SEARCH_SUCCESS,
  SEARCH_FAIL,
  QUERY_POPULAR_SEARCHES,
  QUERY_POPULAR_SEARCHES_SUCCESS,
  QUERY_POPULAR_SEARCHES_FAIL
} from './constants';

const defaultState = {
  searches: [],
  lastSearchGames: []
};

const handlers = {
  [SEARCH]: (state, action) => ({ ...state }),
  [SEARCH_SUCCESS]: (state, { games }) => ({ ...state, lastSearchGames: games }),
  [SEARCH_FAIL]: (state, action) => ({ ...state }),
  [QUERY_POPULAR_SEARCHES]: (state, action) => ({ ...state }),
  [QUERY_POPULAR_SEARCHES_SUCCESS]: (state, { searches }) => ({
    ...state,
    searches
  }),
  [QUERY_POPULAR_SEARCHES_FAIL]: (state, action) => ({ ...state })
};

const search = (state = defaultState, action) => {
  const handler = handlers[action.type];

  if (handler) {
    return handler(state, action);
  }
  return state;
};

export default search;
