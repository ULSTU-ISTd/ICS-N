function Counter() {
  let Time=localStorage["Time"];
  let timer;
  if (Time < 0)
    Time=0;
  if(Time%60>=10)
    timer = Math.floor(Time/60) +':'+Time%60;
  else //для корректного отображения, когда осталось меньше 10секунд
    timer = Math.floor(Time/60) +':0'+Time%60;
  if (Time == 0) {//время истекло
    timer = 'DIE!';
  }
  return timer;
}
