const styles = () => ({
  gameContainer: {
    marginTop: 20,
    padding: 10,
    width: 'calc(100vw - 20px)',
  },
  image: {
    maxWidth: '100%'
  },
  imageWrap: {
    textAlign: 'center'
  }
});

export default styles;
