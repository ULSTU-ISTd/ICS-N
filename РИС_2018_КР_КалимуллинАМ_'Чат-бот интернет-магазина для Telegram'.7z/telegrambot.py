import telebot
from telebot import types
from telebot.types import LabeledPrice, ShippingOption
import const
from geopy.distance import vincenty

bot = telebot.TeleBot(const.API_TOKEN)

# словарь для хранения данных пользователей
user_dict = {}

#класс данных о пользователе
class User:
    def __init__(self, name):
        self.name = name
        self.age = None
        self.sex = None

prices = [LabeledPrice(label='Препарат Vita Improva', amount=670000), LabeledPrice('x', 0)]
shipping_options = [
    ShippingOption(id='self', title='Самовывоз').add_price(LabeledPrice('self', 100)),
    ShippingOption(id='courier', title='Курьер').add_price(LabeledPrice('courier', 500))]

# основная клавиатура для взаимодействия с ботом
markup_menu = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
btn_address = types.KeyboardButton('Ближайшая точка', request_location=True)
btn_payment = types.KeyboardButton('Оплатить')
btn_howtopay = types.KeyboardButton('Другие способы оплаты')
btn_delivery = types.KeyboardButton('Способы доставки')
markup_menu.add(btn_address, btn_payment, btn_howtopay, btn_delivery)

# inline-клавиатура для способов оплаты
markup_inline_payment = types.InlineKeyboardMarkup()
btn_in_cash = types.InlineKeyboardButton('Наличные', callback_data='cash')
btn_in_card = types.InlineKeyboardButton('Картой', callback_data='card')
btn_in_invoice = types.InlineKeyboardButton('Банковский перевод', callback_data='invoice')
markup_inline_payment.add(btn_in_cash, btn_in_card, btn_in_invoice)

# inline-клавиатура для способов доставки
markup_inline_delivery = types.InlineKeyboardMarkup()
btn_in_self = types.InlineKeyboardButton('Самовывоз', callback_data='self')
btn_in_courier = types.InlineKeyboardButton('Доставка курьером', callback_data='courier')
btn_in_post = types.InlineKeyboardButton('Почта России', callback_data='post')
markup_inline_delivery.add(btn_in_self, btn_in_courier, btn_in_post)


# обработчик приветствия
@bot.message_handler(commands=['start'])
def send_welcome(message):
    msg = bot.reply_to(message, "Вас приветствует бот сети магазинов Vita Improva!\nКак мне к Вам обращаться?")
    bot.register_next_step_handler(msg, process_name_step)


# пошаговый опрос пользователя
# имя и полный возраст
def process_name_step(message):
    try:
        chat_id = message.chat.id
        name = message.text
        user = User(name)
        user_dict[chat_id] = user
        msg = bot.reply_to(message, 'Сколько Вам полных лет?')
        bot.register_next_step_handler(msg, process_age_step)
    except Exception as e:
        bot.reply_to(message, 'Произошла ошибка при регистрации! Попробуйте снова.')


# проверка ввода числа, пол пользователя
def process_age_step(message):
    try:
        chat_id = message.chat.id
        age = message.text
        if not age.isdigit():
            msg = bot.reply_to(message, 'Возраст должен быть представлен числом. Так сколько Вам лет?')
            bot.register_next_step_handler(msg, process_age_step)
            return
        user = user_dict[chat_id]
        user.age = age
        markup = types.ReplyKeyboardMarkup(one_time_keyboard=True)
        markup.add('Мужчина', 'Женщина')
        msg = bot.reply_to(message, 'Ваш пол:', reply_markup=markup)
        bot.register_next_step_handler(msg, process_sex_step)
    except Exception as e:
        bot.reply_to(message, 'Произошла ошибка при регистрации! Попробуйте снова.')


# завершение опроса пользователя, дальнейшая передача управления
def process_sex_step(message):
    try:
        chat_id = message.chat.id
        sex = message.text
        user = user_dict[chat_id]
        if (sex == u'Мужчина') or (sex == u'Женщина'):
            user.sex = sex
        else:
            raise Exception()
        bot.send_message(chat_id,
                         'Приятно познакомиться, ' + user.name + '!\nВозраст: ' + str(user.age) + '\nПол: ' + user.sex)
        bot.send_message(chat_id, 'Теперь вы можете оформить заказ, {name}!'.format(name=user.name))

    except Exception as e:
        bot.reply_to(message, 'Что-то пошло не так...')


# обработчик основной клавиатуры
@bot.message_handler(func=lambda message: True)
def echo_all(message):
    if message.text == "Способы доставки":
        bot.reply_to(message, "Выберите, как Вам удобно забрать товар", reply_markup=markup_inline_delivery)

    elif message.text == "Другие способы оплаты":
        bot.reply_to(message, "Выберите описание нужного способа оплаты", reply_markup=markup_inline_payment)

    # по нажатию на "оплатить" происходит оплата с помощью Яндекс.Кассы
    # в тестовом режиме, т.к. не удалось получить токены остальных систем оплаты
    elif message.text == "Оплатить":
        bot.send_message(message.chat.id,
                         "Оплата работает в тестовом режиме, средства с Вашей карты не будут списаны."
                         " Используйте этот номер карты для оплаты: `4242 4242 4242 4242`"
                         "\n\nЭто ваш тестовый платёж с помощью Яндекс.Кассы", parse_mode='Markdown')
        bot.send_invoice(message.chat.id, title='Препарат Vita Improva',
                         description='Хотите прожить долгую жизнь без проблем со здоровьем?'
                                     ' Не тратя при этом сил и времени на физические упражнения?'
                                     ' Покупайте наш инновационный препарат Vita Improva!',
                         provider_token=const.YANDEX_TOKEN,
                         currency='RUB',
                         prices=prices,
                         invoice_payload='VITA IMPROVA',
                         start_parameter='test')

        # опциональная возможность оформить доставку после оплаты
        @bot.shipping_query_handler(func=lambda query: True)
        def shipping(shipping_query):
            print(shipping_query)
            bot.answer_shipping_query(shipping_query.id, ok=True, shipping_options=shipping_options,
                                      error_message='Ох, похоже, что-то пошло не так с оформлением доставки! Мы уже '
                                                    'работаем над проблемой!')

        # проверка успешности проведения транзакции оплаты
        @bot.pre_checkout_query_handler(func=lambda query: True)
        def checkout(pre_checkout_query):
            bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True,
                                          error_message="Произошла ошибка при оплате! Проверьте корректность "
                                                        "введенных данных и попробуйте снова")

        # при успешности оплаты - сообщение с благодарностью
        @bot.message_handler(content_types=['successful_payment'])
        def got_payment(message):
            bot.send_message(message.chat.id,
                             'Ура! Спасибо за покупку! '
                             'Мы будем очень рады, если Вы решите подарить Vita Improva своим родным и друзьям!',
                             parse_mode='Markdown')

    # для резерва - бот просто отвечает на сообщение пользователя
    else:
        bot.reply_to(message, message.text, reply_markup=markup_menu)


# обработчик выбора ближайшего к юзеру магазина
@bot.message_handler(func=lambda message: True, content_types=['location'])
def store_location(message):

    # широта и долгота присланной юзером геолокации
    lon = message.location.longitude
    lat = message.location.latitude

    # перебираем адреса магазинов в кортеже
    distance = []
    for m in const.STORES:
        result = vincenty((m['lats'], m["lons"]), (lat, lon)).kilometers
        distance.append(result)

    # вычисляем расстояние до ближайшего магазина
    index = distance.index(min(distance))

    # присылаем местоположение ближайшего магазина (координаты, название точки, адрес)
    bot.send_message(message.chat.id, "Ближайший к Вам магазин")
    bot.send_venue(message.chat.id,
                   const.STORES[index]['lats'],
                   const.STORES[index]['lons'],
                   const.STORES[index]['title'],
                   const.STORES[index]['address'])


# обработчик описания способов оплаты и доставки
# используются инлайн-клавиатуры, ради удобства пользователя повторяющиеся после каждого нажатия на кнопки
@bot.callback_query_handler(func=lambda call: True)
def call_back_payment(call):
    if call.data == 'cash':
        bot.send_message(call.message.chat.id, text="Наличная оплата производится в рублях в кассе магазина.",
                         reply_markup=markup_inline_payment)
    elif call.data == 'card':
        bot.send_message(call.message.chat.id, text="В настоящее время мы принимаем карты VISA, Maestro и MasterCard.",
                         reply_markup=markup_inline_payment)
    elif call.data == 'invoice':
        bot.send_message(call.message.chat.id,
                         text="Вы можете воспользоваться услугами наших банков-партнёров: Сбербанк, Бинбанк, Альфа-Банк",
                         reply_markup=markup_inline_payment)
    elif call.data == 'self':
        bot.send_message(call.message.chat.id, text="Вы можете забрать товар по будням в 9:00-18:00.",
                         reply_markup=markup_inline_delivery)
    elif call.data == 'courier':
        bot.send_message(call.message.chat.id,
                         text="Для оформления доставки курьером оставьте заявку по номеру 88005553535.",
                         reply_markup=markup_inline_delivery)
    elif call.data == 'post':
        bot.send_message(call.message.chat.id,
                         text="Для оформления доставки Почтой России необходимо иметь клубную карту Vita Improva. "
                              "Её можно бесплатно приобрести в любой точке продаж, с собой необходимо иметь паспорт.",
                         reply_markup=markup_inline_delivery)


# обработчик помощи покупателю (при введении команды /terms)
@bot.message_handler(commands=['terms'])
def command_terms(message):
    bot.send_message(message.chat.id,
                     'Спасибо, что воспользовались нашим ботом!\n'
                     '1. Если курьер доставил ваш заказ с опозданием, позвоните по горячей линии: 88005553535.\n'
                     '2. Если у вас есть претензии по качеству продукции, звоните по номеру 880078752828.\n'
                     '3. Вы можете вернуть деньги в течение 14 календарных дней со дня покупки при наличии упаковки и чека.')

# зацикливание бота
bot.polling()
