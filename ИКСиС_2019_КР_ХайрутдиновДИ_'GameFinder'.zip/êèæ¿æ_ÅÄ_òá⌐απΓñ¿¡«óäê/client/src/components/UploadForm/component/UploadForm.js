import React, { Component } from 'react';
import { YMaps, Map, Placemark } from 'react-yandex-maps';

import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import MenuItem from '@material-ui/core/MenuItem';
import { withStyles } from '@material-ui/core/styles';

import Button from 'components/Button';

import { getUserId } from 'helpers/localStorage';

import styles from './styles';

class UploadForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      game: '',
      description: '',
      publisher: '',
      selectedCategory: 'action'
    };

    this.photoInputRef = React.createRef();

    this.handleFieldChange = this.handleFieldChange.bind(this);
    this.changeSelectedCategory = this.changeSelectedCategory.bind(this);
    this.handleFormSubmit = this.handleFormSubmit.bind(this);
  }

  changeSelectedCategory({ target: { value } }) {
    this.setState({ selectedCategory: value });
  }

  handleFieldChange(fieldName) {
    return event => {
      this.setState({ [fieldName]: event.target.value });
    };
  }

  handleFormSubmit() {
    const { addGame, closeForm } = this.props;
    const { game, selectedCategory, description, publisher } = this.state;

    const image = this.photoInputRef.current.files[0];
    
    addGame(game, selectedCategory, description, publisher, image);
    closeForm();
  }

  render() {
    const { classes } = this.props;
    const { selectedCategory, game, description, publisher } = this.state;

    return (
      <Paper className={classes.formWrap}>
        <form ref={this.formRef} className={classes.form}>
          <div className={classes.formInput}>
            <Typography className={classes.inputTitle}>Название</Typography>
            <TextField
              className={classes.textField}
              placeholder='Name'
              value={game}
              onChange={this.handleFieldChange('game')}
            />
          </div>
          <div className={classes.formInput}>
            <Typography className={classes.inputTitle}>Описание</Typography>
            <TextField
              className={classes.textField}
              placeholder='Description'
              value={description}
              onChange={this.handleFieldChange('description')}
            />
          </div>
          <div className={classes.formInput}>
            <Typography className={classes.inputTitle}>Издатель</Typography>
            <TextField
              className={classes.textField}
              placeholder='Review'
              value={publisher}
              onChange={this.handleFieldChange('publisher')}
            />
          </div>
          <div className={classes.formInput}>
            <Typography className={classes.inputTitle}>
              Фото/Скриншот
            </Typography>
            <TextField
              inputRef={this.photoInputRef}
              className={classes.textField}
              type='file'
            />
          </div>
          <div className={classes.formInput}>
            <Typography className={classes.inputTitle}>Жанр</Typography>
            <TextField
              select
              className={classes.textField}
              value={selectedCategory}
              onChange={this.changeSelectedCategory}
              margin='normal'
            >
              <MenuItem key='action' value='action'>
                Action
              </MenuItem>
              <MenuItem key='adventure' value='adventure'>
                Adventure
              </MenuItem>
              <MenuItem key='rpg' value='rpg'>
                RPG
              </MenuItem>
              <MenuItem key='simulator' value='simulator'>
                Simulator
              </MenuItem>
              <MenuItem key='strategy' value='strategy'>
                Strategy
              </MenuItem>
              <MenuItem key='mmo' value='mmo'>
                MMO
              </MenuItem>
              <MenuItem key='indie' value='indie'>
                Indie
              </MenuItem>
            </TextField>
          </div>
          <div className={classes.submitButtonWrap}>
            <Button onClick={this.handleFormSubmit}>Добавить игру</Button>
          </div>
        </form>
      </Paper>
    );
  }
}

export default withStyles(styles)(UploadForm);
