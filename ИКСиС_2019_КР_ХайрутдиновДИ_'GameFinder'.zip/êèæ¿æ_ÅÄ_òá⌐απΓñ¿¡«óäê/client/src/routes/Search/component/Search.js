import React, { Component } from 'react';

import TextField from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';

import Button from 'components/Button';
import GamesContainer from 'components/GamesContainer';

import styles from './styles';

class Search extends Component {
  constructor(props) {
    super(props);

    this.searchInputRef = React.createRef();
    this.handleSearchButtonClick = this.handleSearchButtonClick.bind(this);
  }

  componentDidMount() {
    const { queryPopularSearches } = this.props;

    queryPopularSearches();
  }

  handleSearchButtonClick() {
    const { search } = this.props;
    const input = this.searchInputRef.current;

    search(input.value);
  }

  handleSearchRequestChange(request) {
    const { search } = this.props;
    const input = this.searchInputRef.current;

    input.value = request;
    search(request);
  }

  render() {
    const { classes, searches: popularSearches, lastSearchGames } = this.props;

    return (
      <div>
        <div className={classes.searchesWrap}>
          Популярные запросы:
          <div className={classes.popularSearches}>
            {popularSearches.map(search => {
              const { query } = search;

              return (
                <Button onClick={() => this.handleSearchRequestChange(query)}>
                  {query}
                </Button>
              );
            })}
          </div>
        </div>
        <div className={classes.searchForm}>
          <TextField inputRef={this.searchInputRef} />
          <Button onClick={this.handleSearchButtonClick}>Найти</Button>
        </div>
        {lastSearchGames && lastSearchGames.length > 0 ? (
          <GamesContainer games={lastSearchGames} />
        ) : (
          'Nothing was found'
        )}
      </div>
    );
  }
}

export default withStyles(styles)(Search);
