﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;

namespace ChessClient
{
    public class ChessClient
    {
        public string host { get; private set; }
        public string user { get; private set; }

        int CurrentGameID; //номер текущей партии

        public ChessClient (string host, string user)
        {
            this.host = host;
            this.user = user;
        }

        public GameInfo GetCurrentGame()
        {
            GameInfo game = new GameInfo(ParseJson(CallServer()));
            CurrentGameID = game.ID;
            //Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //socket.Send()
            return game;
        }

        public GameInfo GetLastGame()
        {
            GameInfo game = new GameInfo(ParseJson(CallServer()));
            CurrentGameID = game.ID-1;
            string json = CallServer(CurrentGameID.ToString());
            var list = ParseJson(json);
            GameInfo lastgame = new GameInfo(list);
            return lastgame;
        }

        public GameInfo SendMove(string move)
        {
            string json = CallServer(CurrentGameID + "/" + move);
            var list = ParseJson(json);
            GameInfo game = new GameInfo(list);
            return game;
        }

        private string CallServer(string param = "")
        {
            WebRequest request = WebRequest.Create(host + user + "/" + param);//обращение
            WebResponse response = request.GetResponse();//получает результат
            using (Stream stream = response.GetResponseStream()) //получаем поток, позволяет закрывать ресурсы после того как работа с ними будет завершена(using)
            using (StreamReader reader = new StreamReader(stream))
                return reader.ReadToEnd();
            //Cookie cookie = new Cookie("MyName", "Alex", "/", "localhost");
            //HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(
            //       host + "/" + param);
            //request.CookieContainer = new CookieContainer();
            //request.CookieContainer.Add(cookie);

            //HttpWebResponse responce = (HttpWebResponse)request.GetResponse();

            //using (StreamReader stream = new StreamReader(
            //        responce.GetResponseStream(), Encoding.UTF8))
            //{
            //    return stream.ReadToEnd();
            //}
        }

        //ассоциативнй массиы
        private NameValueCollection ParseJson(string json)
        {
            NameValueCollection list =new  NameValueCollection();
            string pattern = @"""(\w+)\"":""?([^,""}]*)""?";
            foreach (Match m in Regex.Matches(json, pattern))
                if (m.Groups.Count == 3)
                    list[m.Groups[1].Value] = m.Groups[2].Value;
            return list;
        }
    }
}
