/* */ 
module.exports = require('./inherits');
