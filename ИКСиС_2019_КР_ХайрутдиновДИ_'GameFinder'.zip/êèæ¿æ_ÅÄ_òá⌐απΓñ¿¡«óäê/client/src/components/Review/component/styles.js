const styles = () => ({
  review: {
    position: 'relative',
    width: '100%',
    borderRadius: 5,
    maxHeight: 150
  },
  reviewWrap: {
    position: 'relative',
    margin: '0 .5% 10px .5%',
    padding: 10
  },
  removeIcon: {
    position: 'absolute',
    top: '0px',
    right: '0px',
  }
});

export default styles;
