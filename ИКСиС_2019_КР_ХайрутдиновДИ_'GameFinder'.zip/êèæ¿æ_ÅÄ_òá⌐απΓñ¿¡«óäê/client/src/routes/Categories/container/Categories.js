import { connect } from 'react-redux';

import { queryCategories, queryCategoryGames } from 'store/category/actions';
import { getCategories, getCategoryGames } from 'store/category/selectors';

import Categories from '../component/Categories';

const mapStateToProps = ({ category }) => ({
  categories: getCategories(category),
  categoryGames: getCategoryGames(category)
});

const mapDispatchToProps = dispatch => ({
  queryCategories: () => dispatch(queryCategories()),
  queryCategoryGames: categoryId => dispatch(queryCategoryGames(categoryId))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Categories);
