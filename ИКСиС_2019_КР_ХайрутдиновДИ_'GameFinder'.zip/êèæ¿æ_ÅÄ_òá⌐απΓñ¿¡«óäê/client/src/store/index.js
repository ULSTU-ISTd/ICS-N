import { combineReducers } from 'redux';

import review from './review';
import user from './user';
import category from './category';
import search from './search';
import game from './game';

export default combineReducers({
  user,
  review,
  category,
  search,
  game
});
