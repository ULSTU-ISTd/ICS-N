/* */ 
module.exports = require('./es5/index');
