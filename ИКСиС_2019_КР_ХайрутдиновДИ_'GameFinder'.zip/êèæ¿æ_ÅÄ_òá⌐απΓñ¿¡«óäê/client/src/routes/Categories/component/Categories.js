import React, { Component } from 'react';

import { withStyles } from '@material-ui/core/styles';

import Button from 'components/Button';
import GamesContainer from 'components/GamesContainer';

import styles from './styles';

class Categories extends Component {
  constructor(props) {
    super(props);

    this.state = {
      categories: [],
      categoryGames: {},
      currentCategory: ''
    };
  }

  componentDidMount() {
    const { queryCategories } = this.props;

    queryCategories();
  }

  componentWillReceiveProps({ categories, categoryGames }) {
    if (categories.length === 0) {
      return;
    }

    const { currentCategory } = this.state;

    if (currentCategory === '') {
      this.showFirstCategory(categories);
      return;
    }

    this.setState({ categoryGames });
  }

  changeCurrentCategory(categoryId, categoryName) {
    const { queryCategoryGames } = this.props;

    this.setState({ currentCategory: categoryName });
    queryCategoryGames(categoryId);
  }

  showFirstCategory(categories) {
    const { queryCategoryGames } = this.props;

    const firstCategory = categories[0];
    const categoryName = firstCategory.name;
    const categoryId = firstCategory._id;

    queryCategoryGames(categoryId);
    this.setState({ categories, currentCategory: categoryName });
  }

  render() {
    const { classes } = this.props;
    const { categories, categoryGames, currentCategory } = this.state;
    const currentCategoryGames = categoryGames[currentCategory];
    
    return (
      <section className={classes.categories}>
        <header className={classes.categoriesHeader}>
          {categories.map((category, index) => {
            const categoryId = category._id;
            const categoryName = category.name;

            return (
              <Button
                key={index}
                isActive={currentCategory === categoryName}
                onClick={() =>
                  this.changeCurrentCategory(categoryId, categoryName)
                }
              >
                {categoryName}
              </Button>
            );
          })}
        </header>
        <main className={classes.categoriesContent}>
          {currentCategoryGames ? <GamesContainer games={currentCategoryGames} /> : null}
        </main>
      </section>
    );
  }
}

export default withStyles(styles)(Categories);
