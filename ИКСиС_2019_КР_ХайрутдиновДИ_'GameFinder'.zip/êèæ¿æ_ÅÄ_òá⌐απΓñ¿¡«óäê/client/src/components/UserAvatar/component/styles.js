import { LIGHT_GREEN } from 'styles/colors';

const styles = () => ({
  avatarWrap: {
    width: 50,
    margin: 5,
    background: LIGHT_GREEN,
    borderRadius: 5
  },
  avatar: {
    maxWidth: '100%',
    maxHeight: '100%'
  }
});

export default styles;
