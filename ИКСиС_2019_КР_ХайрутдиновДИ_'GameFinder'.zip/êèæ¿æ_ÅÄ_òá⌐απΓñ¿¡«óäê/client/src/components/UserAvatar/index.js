import UserAvatar from './component/UserAvatar';

export default UserAvatar;
