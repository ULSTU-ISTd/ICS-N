/* */ 
require('../modules/es7.array.includes');
require('../modules/es7.string.at');
require('../modules/es7.string.pad-left');
require('../modules/es7.string.pad-right');
require('../modules/es7.string.trim-left');
require('../modules/es7.string.trim-right');
require('../modules/es7.regexp.escape');
require('../modules/es7.object.get-own-property-descriptors');
require('../modules/es7.object.values');
require('../modules/es7.object.entries');
require('../modules/es7.map.to-json');
require('../modules/es7.set.to-json');
module.exports = require('../modules/$.core');
