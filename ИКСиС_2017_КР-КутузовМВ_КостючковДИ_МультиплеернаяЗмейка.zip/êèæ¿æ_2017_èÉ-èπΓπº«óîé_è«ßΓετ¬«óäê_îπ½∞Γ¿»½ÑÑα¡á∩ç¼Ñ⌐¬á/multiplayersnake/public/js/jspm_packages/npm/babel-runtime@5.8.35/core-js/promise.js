/* */ 
module.exports = { "default": require("core-js/library/fn/promise"), __esModule: true };