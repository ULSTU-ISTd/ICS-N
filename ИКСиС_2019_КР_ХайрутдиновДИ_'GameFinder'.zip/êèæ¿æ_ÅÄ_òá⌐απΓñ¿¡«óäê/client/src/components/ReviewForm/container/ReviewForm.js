import { connect } from 'react-redux';

import { addReview } from 'store/review/actions';

import ReviewForm from '../component/ReviewForm';

const mapDispatchToProps = {
  addReview
};

export default connect(
  null,
  mapDispatchToProps
)(ReviewForm);
