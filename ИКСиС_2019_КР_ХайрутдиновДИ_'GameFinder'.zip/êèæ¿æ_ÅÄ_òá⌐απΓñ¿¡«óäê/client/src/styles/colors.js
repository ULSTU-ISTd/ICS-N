export const LIGHT_GREEN = '#F1F7ED';
export const DARK_GREEN = '#243E36';
