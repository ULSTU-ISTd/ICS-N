import {
  QUERY_CATEGORIES,
  QUERY_CATEGORIES_SUCCESS,
  QUERY_CATEGORIES_ERROR,
  QUERY_CATEGORY,
  QUERY_CATEGORY_SUCCESS,
  QUERY_CATEGORY_ERROR
} from './constants';

const defaultState = {
  categories: [],
  categoryGames: {}
};

const handlers = {
  [QUERY_CATEGORIES]: state => ({ ...state }),
  [QUERY_CATEGORIES_SUCCESS]: (state, { categories }) => ({
    ...state,
    categories
  }),
  [QUERY_CATEGORIES_ERROR]: state => ({ ...state }),
  [QUERY_CATEGORY]: state => ({ ...state }),
  [QUERY_CATEGORY_SUCCESS]: (state, { data: { name, games } }) => ({
    ...state,
    categoryGames: { ...state.categoryReviews, [name]: games }
  }),
  [QUERY_CATEGORY_ERROR]: state => ({ ...state })
};

const category = (state = defaultState, action) => {
  const handler = handlers[action.type];

  if (handler) {
    return handler(state, action);
  }
  return state;
};

export default category;
