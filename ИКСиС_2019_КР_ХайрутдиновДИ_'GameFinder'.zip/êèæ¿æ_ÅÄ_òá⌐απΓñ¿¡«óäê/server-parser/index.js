import 'dotenv/config';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import route from './route';

const app = express();
const port = process.env.PORT || 8080;

app.use(cors());
app.use(
  bodyParser.json({ limit: '10mb', extended: true }),
  bodyParser.urlencoded({ limit: '10mb', extended: true })
);

app.use('/', route);

// 404 Error handler
app.use((req, res, next) => {
  const error = new Error('URL not found');
  error.status = 404;
  next();
});

app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message
    }
  });
});

app.listen(port, () => {
  console.log(`App listening on port ${port}!`);
});
