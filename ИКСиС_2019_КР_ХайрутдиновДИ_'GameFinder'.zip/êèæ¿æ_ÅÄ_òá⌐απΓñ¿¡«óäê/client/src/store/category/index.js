import categories from './reducer';

export default categories;
