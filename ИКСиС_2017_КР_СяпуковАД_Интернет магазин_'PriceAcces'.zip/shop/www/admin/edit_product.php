<?php
session_start();
if ($_SESSION['auth_admin'] == "yes_auth")
{
	define('myeshop', true);
       
       if (isset($_GET["logout"]))
    {
        unset($_SESSION['auth_admin']);
        header("Location: login.php");
    }

  $_SESSION['urlpage'] = "<a href='index.php' >Главная</a> \ <a href='tovar.php' >Товары</a> \ <a>Изменение товара</a>";
  
  include("include/db_connect.php");
  include("include/functions.php"); 
  $id = clear_string($_GET["id"]);
  $action = clear_string($_GET["action"]);
if (isset($action))
{
   switch ($action) {

	    case 'delete':
     
         
         if (file_exists("../product_img/".$_GET["img"]))
        {
          unlink("../product_img/".$_GET["img"]);  
        }
                 
    
	    break;

	} 
}
    if ($_POST["submit_save"])
    {
      $error = array();
    
    // Проверка полей
        
       if (!$_POST["form_title"])
      {
         $error[] = "Укажите название товара";
      }
      
       if (!$_POST["form_price"])
      {
         $error[] = "Укажите цену";
      }
          
       if (!$_POST["form_category"])
      {
         $error[] = "Укажите категорию";         
      }else
      {
       	$result = mysql_query("SELECT * FROM category WHERE id='{$_POST["form_category"]}'",$link);
        $row = mysql_fetch_array($result);
        $selectbrand = $row["brand"];

      }
 
 
        if (empty($_POST["upload_image"]))
      {        
      include("actions/upload-image.php");
      unset($_POST["upload_image"]);           
      } 
      
       if (empty($_POST["galleryimg"]))
      {        
      include("actions/upload-gallery.php"); 
      unset($_POST["galleryimg"]);                 
      }
      
 // Проверка чекбоксов
                    
      
                                      
       if (count($error))
       {           
            $_SESSION['message'] = "<p id='form-error'>".implode('<br />',$error)."</p>";
            
       }else
       {
                           
       $querynew = "title='{$_POST["form_title"]}',price='{$_POST["form_price"]}',brand='$selectbrand',description='{$_POST["txt1"]}',type_product='{$_POST["form_type"]}',brand_id='{$_POST["form_category"]}'"; 
           
       $update = mysql_query("UPDATE table_products SET $querynew WHERE product_id = '$id'",$link); 
                   
      $_SESSION['message'] = "<p id='form-success'>Товар успешно изменен!</p>";
                
}
            
}   

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    <link href="css/reset.css" rel="stylesheet" type="text/css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <link href="jquery_confirm/jquery_confirm.css" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src="js/jquery-1.8.2.min.js"></script> 
    <script type="text/javascript" src="js/script.js"></script>   
    <script type="text/javascript" src="./ckeditor/ckeditor.js"></script>  
	<title>Панель Управления</title>
</head>
<body>
<div id="block-body">
<?php
	include("include/block-header.php");
?>
<div id="block-content">
<div id="block-parameters">
<p id="title-page" >Добавление товара</p>
</div>
<?php
if (isset($msgerror)) echo '<p id="form-error" align="center">'.$msgerror.'</p>';

		 if(isset($_SESSION['message']))
		{
		echo $_SESSION['message'];
		unset($_SESSION['message']);
		}
        
     if(isset($_SESSION['answer']))
		{
		echo $_SESSION['answer'];
		unset($_SESSION['answer']);
		} 
?>
<?php
	$result = mysql_query("SELECT * FROM table_products WHERE product_id='$id'",$link);
    
If (mysql_num_rows($result) > 0)
{
$row = mysql_fetch_array($result);
do
{
    
echo '

<form enctype="multipart/form-data" method="post">
<ul id="edit-tovar">

<li>
<label>Название товара</label>
<input type="text" name="form_title" value="'.$row["title"].'" />
</li>

<li>
<label>Цена</label>
<input type="text" name="form_price" value="'.$row["price"].'"  />
</li>

';    
    
$category = mysql_query("SELECT * FROM category",$link);
    
If (mysql_num_rows($category) > 0)
{
$result_category = mysql_fetch_array($category);

if ($row["type_product"] == "МужскиеАксессуары") $type_men = "selected";
if ($row["type_product"] == "ЖенскиеАксессуары") $type_women = "selected";
if ($row["type_product"] == "АвтомобильныеАксессуары") $type_auto = "selected";



echo '
<li>
<label>Тип товара</label>
<select name="form_type" id="type" size="1" >

<option '.$type_men.' value="МужскиеАксессуары" >МужскиеАксессуары</option>
<option '.$type_women.' value="ЖенскиеАксессуары" >ЖенскиеАксессуары</option>
<option '.$type_auto.' value="АвтомобильныеАксессуары" >АвтомобильныеАксессуары</option>

</select>
</li>

<li>
<label>Категория</label>
<select name="form_category" size="10" >
';


do
{
  
  echo '
  
  <option value="'.$result_category["id"].'" >'.$result_category["type"].'-'.$result_category["brand"].'</option>
  
  ';
    
}
 while ($result_category = mysql_fetch_array($category));
}
echo '
</select>
</ul> 
';

   if  (strlen($row["image"]) > 0 && file_exists("../product_img/".$row["image"]))
{
$img_path = '../product_img/'.$row["image"];
$max_width = 110; 
$max_height = 110; 
 list($width, $height) = getimagesize($img_path); 
$ratioh = $max_height/$height; 
$ratiow = $max_width/$width; 
$ratio = min($ratioh, $ratiow); 
// New dimensions 
$width = intval($ratio*$width); 
$height = intval($ratio*$height); 

echo '
<label class="stylelabel" >Основная картинка</label>
<div id="baseimg">
<img src="'.$img_path.'" width="'.$width.'" height="'.$height.'" />
<a href="edit_product.php?id='.$row["product_id"].'&img='.$row["image"].'&action=delete" ></a>
</div>

';
   
}else
{  
echo '
<label class="stylelabel" >Основная картинка</label>

<div id="baseimg-upload">
<input type="hidden" name="MAX_FILE_SIZE" value="5000000"/>
<input type="file" name="product_img" />

</div>
';
}

echo '     
 
<h3 class="h3click" >Описание товара</h3>
<div class="div-editor2" >
<textarea id="editor2" name="txt1" cols="100" rows="20">'.$row["description"].'</textarea>
		<script type="text/javascript">
			var ckeditor1 = CKEDITOR.replace( "editor2" );
			AjexFileManager.init({
				returnTo: "ckeditor",
				editor: ckeditor1
			});
		</script>
 </div>                 


<label class="stylelabel" >Галлерея картинок</label>

<div id="objects" >

<div id="addimage1" class="addimage">
<input type="hidden" name="MAX_FILE_SIZE" value="2000000"/>
<input type="file" name="galleryimg[]" />
</div>

</div>

<p id="add-input" >Добавить</p>
 
<ul id="gallery-img"> 
 ';
 
$query_img = mysql_query("SELECT * FROM uploads_images WHERE product_id='$id'",$link);

If (mysql_num_rows($query_img) > 0)
{
    
$result_img = mysql_fetch_array($query_img);
do
{
if  (strlen($result_img["image"]) > 0 && file_exists("../product_img/".$result_img["image"]))
{
$img_path = '../product_img/'.$result_img["image"];
$max_width = 100; 
$max_height = 100; 
 list($width, $height) = getimagesize($img_path); 
$ratioh = $max_height/$height; 
$ratiow = $max_width/$width; 
$ratio = min($ratioh, $ratiow); 
// New dimensions 
$width = intval($ratio*$width); 
$height = intval($ratio*$height);  

}else
{
$img_path = "./img/noimages.png";
$width = 80;
$height = 70;
}

echo ' 
 <li id="del'.$result_img["id"].'" >
 <img src="'.$img_path.'" width="'.$width.'" height="'.$height.'" title="'.$result_img["image"].'" />
 ';

  echo '
 <a class="del-img" img_id="'.$result_img["id"].'" ></a>       
';   


echo '</li>';
    
    
}while ($result_img = mysql_fetch_array($query_img));
} 
 
 
echo ' 
 </ul>  
';

 

echo ' 


    <p align="right" ><input type="submit" id="submit_form" name="submit_save" value="Сохранить"/></p>     
</form>
';

}while ($row = mysql_fetch_array($result));
}
?> 




</div>
</div>
</body>
</html>
<?php
}else
{
    header("Location: login.php");
}
?>