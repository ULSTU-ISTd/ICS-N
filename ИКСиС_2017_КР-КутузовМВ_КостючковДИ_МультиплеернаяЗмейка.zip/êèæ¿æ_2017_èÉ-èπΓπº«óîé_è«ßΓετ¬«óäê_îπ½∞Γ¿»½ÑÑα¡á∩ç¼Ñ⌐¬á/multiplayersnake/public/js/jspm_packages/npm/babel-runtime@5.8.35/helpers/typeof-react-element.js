/* */ 
"use strict";

var _Symbol = require("babel-runtime/core-js/symbol")["default"];

exports["default"] = typeof _Symbol === "function" && _Symbol."for" && _Symbol."for"("react.element") || 60103;
exports.__esModule = true;