const styles = () => ({
  categories: {
    width: '100%'
  },
  categoriesHeader: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center'
  },
});

export default styles;
