/* */ 
require('../modules/core.delay');
module.exports = require('../modules/$.core').delay;
