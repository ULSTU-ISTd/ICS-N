/* */ 
module.exports = { "default": require("core-js/library/fn/math/imul"), __esModule: true };