import { Router } from 'express';
import multer from 'multer';
import mongoose from 'mongoose';

const router = Router();
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/photos');
  },
  filename: (req, file, cb) => {
    const date = new Date();
    const dateISO = date.toISOString();
    const uploadedFileName = `${dateISO}_${file.originalname}`.replace(
      /:/gi,
      '_'
    );

    cb(null, uploadedFileName);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 1024 * 1024 * 10 //10mb
  }
});

router.get('/', async ({ context: { models } }, res) => {
  try {
    const games = await models.Game.find({}).populate({
      path: 'reviews',
      populate: { path: 'author', select: 'login' }
    });

    return res.status(200).json({ data: { games }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.post('/update/:gameId', async (req, res) => {
  try {
    const {
      context: { models },
      body: { direction },
      params: { gameId }
    } = req;

    if (direction === 'up') {
      await models.Game.updateOne(
        { _id: gameId },
        { $inc: { thumbUp: 1 } }
      );
    } else {
      await models.Game.updateOne(
        { _id: gameId },
        { $inc: { thumbDown: 1 } }
      );
    }

    return res.status(200).json({ data: 'Game rating updated', error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.post('/', upload.single('image'), async (req, res) => {
  try {
    const {
      context: { models },
      body: { name, description, publisher, category },
      file: { path }
    } = req;

    const findedCategory = await models.Category.findOne(
      { name: category },
      { name: 0, reviews: 0 }
    );

    const gameId = new mongoose.Types.ObjectId();

    const game = new models.Game({
      _id: gameId,
      name,
      description,
      publisher,
      url: `http://localhost:${process.env.PORT}/${path}`.replace(/\\/gi, '/'),
      thumbUp: 0,
      thumbDown: 0,
      category: findedCategory._id,
      reviews: []
    });

    game.save();

    await models.Category.updateOne(
      { name: category },
      { $push: { games: gameId } }
    );

    res.status(200).json({
      data: { game },
      error: false
    });
  } catch (e) {
    res.status(500).json({
      data: null,
      error: e.message
    });
  }
});

export default router;
