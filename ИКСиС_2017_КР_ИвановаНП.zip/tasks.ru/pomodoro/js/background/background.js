var tmp = 1;
var myNotificationID;
var timer="";
////////////////////////////////отсчет////////////////////////////////////////
createAlarm();
setInterval(function () {
  if(!getAlarm())
  updateBadge({ text: Counter()})
},1000);

var ajaxNotificationButton = debounce(ajaxNotificationButton, 10000);
//-----------------------------Событие на уведомление-----------------
chrome.notifications.onButtonClicked.addListener(function(notifId, btnIdx) {
  if (notifId === myNotificationID) {
    chrome.notifications.clear(notifId)
    if (btnIdx === 0) {
      console.log('YES');
      ajaxNotificationButton('true');
      delete(localStorage['Task_ID']);
      delete(localStorage['Task_Text']);
    } else if (btnIdx === 1) {
      ajaxNotificationButton();
      console.log('NO');
    }
  }
});

chrome.notifications.onClosed.addListener(function(notifId,byUser) {
  ajaxNotificationButton();
   console.log('NO1');
});
//-----------------------------Событие на таймер-----------------
chrome.alarms.onAlarm.addListener(function (){
  console.log('END TIMER!!!!');
  chrome.alarms.clearAll(); // тут очистка всех таймеров
  createAlarm();
});
