/* */ 
module.exports = { "default": require("core-js/library/fn/math/asinh"), __esModule: true };