import apiClient from 'utils/apiClient';
import {
  LOGIN,
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  REGISTER,
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  REQUEST_USER_DATA,
  REQUEST_USER_DATA_SUCCESS,
  REQUEST_USER_DATA_ERROR
} from './constants';

export function login(login, password) {
  return dispatch => {
    dispatch({ type: LOGIN });

    apiClient
      .post('user/login', {
        login,
        password
      })
      .then(({ data, error }) => {
        if (error) {
          dispatch({ type: LOGIN_FAIL });
        }

        if (data.isUserAdmin) {
          localStorage.setItem('admin', true);
        }
        dispatch({ type: LOGIN_SUCCESS, userId: data.loggedUserId });
      });
  };
}

export function register(login, password) {
  return dispatch => {
    dispatch({ type: REGISTER });

    apiClient
      .post('user/register', {
        login,
        password
      })
      .then(({ data, error }) => {
        if (error) {
          dispatch({ type: REGISTER_FAIL });
        }

        dispatch({ type: REGISTER_SUCCESS, userId: data });
      });
  };
}

export function requestUserData(userId) {
  return dispatch => {
    dispatch({ type: REQUEST_USER_DATA });

    apiClient.get(`user/${userId}`).then(({ data, error }) => {
      if (error) {
        dispatch({ type: REQUEST_USER_DATA_ERROR });
        return;
      }

      const { user } = data;

      dispatch({ type: REQUEST_USER_DATA_SUCCESS, user });
    });
  };
}
