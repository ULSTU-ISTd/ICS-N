import 'dotenv/config';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import mongoose from 'mongoose';
import axios from 'axios';

import models from './models';
import routes from './routes';

const app = express();
const port = process.env.PORT || 8080;

const dbConnect = mongoose.connect(process.env.DATABASE_URL, {
  useNewUrlParser: true
});

mongoose.set('useCreateIndex', true);

app.use('/uploads', express.static('uploads'));
app.use(cors());
app.use(
  bodyParser.json({ limit: '10mb', extended: true }),
  bodyParser.urlencoded({ limit: '10mb', extended: true })
);

app.use(async (req, res, next) => {
  req.context = {
    models
  };
  next();
});

app.use(async (req, res, next) => {
  if (req.originalUrl !== '/parse') {
    next();
    return;
  }

  const {
    data: { data }
  } = await axios.get('http://localhost:8080');

  if (!data.games) {
    next();
    return;
  }

  for await (const game of data.games) {
    const category = 'rpg';

    const findedCategory = await models.Category.findOne(
      { name: category },
      { name: 0, reviews: 0 }
    );

    const gameId = new mongoose.Types.ObjectId();

    const newGame = new models.Game({
      _id: gameId,
      name: game.name || 'No name',
      description: game.description || 'No description',
      publisher: game.publisher || 'No publisher',
      url: game.cover,
      thumbUp: 0,
      thumbDown: 0,
      category: findedCategory._id,
      reviews: []
    });

    newGame.save();

    await models.Category.updateOne(
      { name: category },
      { $push: { games: gameId } }
    );
  }
  next();
});

app.use('/games', routes.games);
app.use('/reviews', routes.reviews);
app.use('/categories', routes.categories);
app.use('/user', routes.user);
app.use('/search', routes.search);

// 404 Error handler
app.use((req, res, next) => {
  const error = new Error('URL not found');
  error.status = 404;
  next();
});

app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message
    }
  });
});

dbConnect.then(
  () => {
    app.listen(port, () => {
      console.log(`App listening on port ${port}!`);
    });
  },
  err => {
    console.log(err);
  }
);
