import Review from './component/Review';

export default Review;