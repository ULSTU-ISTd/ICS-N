import { Router } from 'express';
import mongoose from 'mongoose';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const users = await models.User.find({}, { login: 1 });

    return res.status(200).json({ data: { users }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.get('/:userId', async (req, res) => {
  try {
    const {
      context: { models },
      params: { userId }
    } = req;

    const user = await models.User.findOne(
      { _id: userId },
      { password: 0 }
    ).populate({ path: 'reviews', populate: { path: 'game' } });

    return res.status(200).json({ data: { user }, error: null });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const {
      context: { models },
      body: { login, password }
    } = req;

    let isUserAdmin = false;

    if (login === 'admin') {
      isUserAdmin = true;
    }

    const { _id: loggedUserId } = await models.User.findOne({
      login,
      password
    });

    return res
      .status(200)
      .json({ data: { loggedUserId, isUserAdmin }, error: null });
  } catch (err) {
    return res.status(500).json({
      data: null,
      error: err.message
    });
  }
});

router.post('/register', async (req, res) => {
  try {
    const {
      context: { models },
      body: { login, password }
    } = req;

    const userId = new mongoose.Types.ObjectId();

    const user = new models.User({
      _id: userId,
      login,
      password,
      reviews: []
    });

    await user.save();

    return res.status(200).json({ data: userId, error: null });
  } catch (err) {
    return res.status(500).json({
      data: null,
      error: err.message
    });
  }
});

export default router;
