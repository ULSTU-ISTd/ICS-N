-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Май 16 2017 г., 00:26
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `magaz`
--
CREATE DATABASE `magaz` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `magaz`;

-- --------------------------------------------------------

--
-- Структура таблицы `buy_products`
--

CREATE TABLE IF NOT EXISTS `buy_products` (
  `buy_id_order` int(11) NOT NULL,
  `buy_id_product` int(11) NOT NULL,
  `buy_count_product` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `buy_products`
--

INSERT INTO `buy_products` (`buy_id_order`, `buy_id_product`, `buy_count_product`) VALUES
(4, 4, 2),
(4, 2, 1),
(4, 5, 1),
(5, 4, 2),
(5, 2, 1),
(5, 5, 1),
(6, 4, 2),
(6, 2, 1),
(6, 5, 1),
(7, 4, 2),
(7, 2, 1),
(7, 5, 1),
(8, 4, 2),
(8, 2, 1),
(8, 5, 3),
(8, 0, 5),
(8, 1, 1),
(8, 1, 1),
(8, 6, 1),
(8, 4, 2),
(8, 2, 1),
(8, 5, 3),
(8, 0, 5),
(8, 1, 2),
(8, 1, 1),
(8, 6, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id_product` int(11) NOT NULL,
  `cart_price` int(11) NOT NULL,
  `cart_count` int(11) NOT NULL DEFAULT '1',
  `cart_datetime` datetime NOT NULL,
  `cart_ip` varchar(100) NOT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `cart`
--

INSERT INTO `cart` (`cart_id`, `cart_id_product`, `cart_price`, `cart_count`, `cart_datetime`, `cart_ip`) VALUES
(1, 4, 280, 2, '2017-04-06 15:17:42', '127.0.0.1'),
(2, 2, 490, 1, '2017-04-06 17:28:01', '127.0.0.1'),
(3, 5, 799, 3, '2017-04-06 17:28:03', '127.0.0.1'),
(4, 0, 0, 5, '2017-04-07 00:11:29', '127.0.0.1'),
(5, 1, 390, 3, '2017-04-07 01:22:42', '127.0.0.1'),
(6, 1, 390, 1, '2017-04-07 01:22:42', '127.0.0.1'),
(7, 6, 490, 2, '2017-04-10 23:09:12', '127.0.0.1');

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL,
  `brand` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `type`, `brand`) VALUES
(1, 'МужскиеАксессуары', 'Часы'),
(2, 'МужскиеАксессуары', 'Браслеты'),
(3, 'МужскиеАксессуары', 'Очки'),
(4, 'МужскиеАксессуары', 'Кошельки'),
(5, 'ЖенскиеАксессуары', 'Часы'),
(6, 'ЖенскиеАксессуары', 'Браслеты'),
(7, 'ЖенскиеАксессуары', 'Очки'),
(8, 'ЖенскиеАксессуары', 'Кошельки'),
(9, 'АвтомобильныеАксессуары', 'Ароматизаторы');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_datetime` datetime NOT NULL,
  `order_confirmed` int(1) NOT NULL DEFAULT '0',
  `order_dostavka` varchar(255) NOT NULL,
  `order_fio` text NOT NULL,
  `order_address` text NOT NULL,
  `order_phone` varchar(50) NOT NULL,
  `order_note` text NOT NULL,
  `order_email` varchar(50) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`order_id`, `order_datetime`, `order_confirmed`, `order_dostavka`, `order_fio`, `order_address`, `order_phone`, `order_note`, `order_email`) VALUES
(4, '2017-04-06 17:46:28', 0, 'Курьерам', 'Сяпуков Роман Дмитриевич', 'Сурова 35-204', '89372786654', 'asd', 'kikopro@yandex.ru'),
(5, '2017-04-06 17:48:51', 0, 'По почте', 'Сяпуков Красава Иванович', 'asdsdfsdf', '234234234', 'asfsdfgdfg', 'kikopro@height.ru'),
(6, '2017-04-06 20:58:54', 0, 'По почте', 'Сяпуков Красава Иванович', 'asdsdfsdf', '234234234', 'asfsdfgdfg', 'kikopro@height.ru'),
(7, '2017-04-06 21:06:08', 1, 'По почте', 'Сяпуков Красава Иванович', 'asdsdfsdf', '234234234', 'asfsdfgdfg', 'kikopro@height.ru'),
(8, '2017-05-12 20:22:28', 1, 'Курьерам', '1111', '1111', '1111', '1111', '1111@111.ru');

-- --------------------------------------------------------

--
-- Структура таблицы `reg_admin`
--

CREATE TABLE IF NOT EXISTS `reg_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `reg_admin`
--

INSERT INTO `reg_admin` (`id`, `login`, `pass`) VALUES
(1, 'admin', '123'),
(2, 'lol', '123');

-- --------------------------------------------------------

--
-- Структура таблицы `reg_user`
--

CREATE TABLE IF NOT EXISTS `reg_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `patronymic` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `datetime` datetime NOT NULL,
  `ip` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `reg_user`
--

INSERT INTO `reg_user` (`id`, `login`, `pass`, `surname`, `name`, `patronymic`, `email`, `phone`, `address`, `datetime`, `ip`) VALUES
(14, 'admin', '9nm2rv8q60e242367f7741bc77f3fc03f3b5005e2yo6z', 'Сяпуков', 'Роман', 'Дмитриевич', 'kikopro@yandex.ru', '89372786654', 'Сурова 35-204', '2017-03-22 22:02:42', '127.0.0.1');

-- --------------------------------------------------------

--
-- Структура таблицы `table_products`
--

CREATE TABLE IF NOT EXISTS `table_products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `datetime` datetime NOT NULL,
  `visible` int(11) NOT NULL DEFAULT '1',
  `count` int(11) NOT NULL DEFAULT '0',
  `type_product` varchar(255) NOT NULL,
  `brand_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `table_products`
--

INSERT INTO `table_products` (`product_id`, `title`, `price`, `brand`, `image`, `description`, `datetime`, `visible`, `count`, `type_product`, `brand_id`) VALUES
(1, 'Мужские часы Panerai Luminor Marina', 390, 'Часы', 'img1.png', 'Человек, который интересуется часами, определенно  слышал про такой бренд как Panerai. Этот человек прекрасно знает, что это не  просто очередной бренд, а нечто большее. На самом деле, данный производитель  отличается тем, что не разменивается на мелочи, а производит исключительно  высококлассный товар.<br /> Все привыкли к тому, что если вещь шикарная, то на  ней должно быть много всего. Продукция Panerai отличается именно тем, что  является роскошной, будучи истинной классикой. Любой аксессуар, произведенный  данной компанией, необычайно строгий.<br /> Основал компанию Джовании Панераи. Этот человек был  известен своей скромностью. Несмотря на эту черту своего характера, он создавал  такие часы, которые вызывали восторг практически у каждого человека.<br /> Первая уникальная модель была создана еще в прошлом  столетии. Известно, что часы купил Сильвестр Сталлоне. Учитывая, что аксессуар  носил легендарный актер, Джовании Панераи стал прославленным мастером часового  дела.<br /> На сегодняшний день есть огромное количество разных  часов, которые достойны внимания. Несмотря на это, аксессуары, которые  производит компания Panerai, по сей день остаются популярными и  востребованными.', '2017-03-06 00:00:00', 1, 3, 'МужскиеАксессуары', 1),
(2, 'Кожанный браслет Pandora style magic', 490, 'Браслеты', 'imgload-263.jpg', '', '0000-00-00 00:00:00', 1, 1, 'МужскиеАксессуары', 2),
(4, 'Автомобильный ароматизатор мешочек счастья', 280, 'Ароматизаторы', 'img3.jpg', '', '0000-00-00 00:00:00', 1, 2, 'АвтомобильныеАксессуары', 9),
(5, 'Женский кошелек Baellery', 799, 'Кошельки', 'img4.png', '', '2017-03-22 03:17:06', 1, 7, 'ЖенскиеАксессуары', 0),
(6, 'Кожанный браслет Pandora style magic', 4903, 'Браслеты', 'imgload-699.jpg', '<p>Человек, который интересуется часами, определенно слышал про такой бренд как Panerai. Этот человек прекрасно знает, что это не просто очередной бренд, а нечто большее. На самом деле, данный производитель отличается тем, что не разменивается на мелочи, а производит исключительно высококлассный товар.<br />\r\nВсе привыкли к тому, что если вещь шикарная, то на ней должно быть много всего. Продукция Panerai отличается именно тем, что является роскошной, будучи истинной классикой. Любой аксессуар, произведенный данной компанией, необычайно строгий.<br />\r\nОсновал компанию Джовании Панераи. Этот человек был известен своей скромностью. Несмотря на эту черту своего характера, он создавал такие часы, которые вызывали восторг практически у каждого человека.<br />\r\nПервая уникальная модель была создана еще в прошлом столетии. Известно, что часы купил Сильвестр Сталлоне. Учитывая, что аксессуар носил легендарный актер, Джовании Панераи стал прославленным мастером часового дела.<br />\r\nНа сегодняшний день есть огромное количество разных часов, которые достойны внимания. Несмотря на это, аксессуары, которые производит компания Panerai, по сей день остаются популярными и востребованными.</p>\r\n', '0000-00-00 00:00:00', 1, 11, 'МужскиеАксессуары', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `uploads_images`
--

CREATE TABLE IF NOT EXISTS `uploads_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `uploads_images`
--

INSERT INTO `uploads_images` (`id`, `product_id`, `image`) VALUES
(3, 6, 'imgloadgallery-252.jpg'),
(4, 6, 'imgloadgallery-149.jpg'),
(5, 6, 'imgloadgallery-249.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(5) NOT NULL,
  `Username` varchar(5) NOT NULL,
  `Password` int(11) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`Id`, `Name`, `Username`, `Password`) VALUES
(3, 'aklas', 'aklas', 698),
(4, 'alexa', 'alexa', 698);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
