import Search from './container/Search';

export default Search;
