import Categories from './container/Categories';

export default Categories;
