import { Router } from 'express';
import mongoose from 'mongoose';

const router = Router();

router.get('/', async ({ context: { models } }, res) => {
  try {
    const reviews = await models.Review.find()
      .populate('game')
      .execPopulate();

    return res.status(200).json({ data: { reviews }, error: false });
  } catch (err) {
    return res.status(500).json({ data: null, error: err.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const {
      context: { models },
      query: { title, userReview, authorId, gameId }
    } = req;

    const reviewId = new mongoose.Types.ObjectId();

    const review = new models.Review({
      _id: reviewId,
      title,
      review: userReview,
      author: authorId,
      uploadTime: Date.now(),
      game: gameId
    });

    await review.save();

    await models.Game.updateOne(
      { _id: gameId },
      { $push: { reviews: reviewId } }
    );

    await models.User.updateOne(
      { _id: authorId },
      { $push: { reviews: reviewId } }
    );

    const returnReview = await models.Review.findOne({
      _id: reviewId
    }).populate({ path: 'author', select: 'login ' });

    res.status(200).json({
      data: { returnReview },
      error: false
    });
  } catch (e) {
    res.status(500).json({
      data: null,
      error: e.message
    });
  }
});

router.post('/delete/:reviewId', async (req, res) => {
  try {
    const {
      context: { models },
      params: { reviewId }
    } = req;

    await models.Review.deleteOne({ _id: reviewId });

    await models.Game.updateMany({}, { $pull: { reviews: reviewId } });

    await models.User.updateMany({}, { $pull: { reviews: reviewId } });
    
    res.status(200).json({
      data: 'success',
      error: false
    });
  } catch (e) {
    res.status(500).json({
      data: null,
      error: e.message
    });
  }
});

export default router;
