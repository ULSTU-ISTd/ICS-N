import { DARK_GREEN } from 'styles/colors';

const styles = () => ({
  authWrap: {
    maxWidth: 500
  },
  tabHeaders: {
    borderBottom: `1px solid ${DARK_GREEN}`
  },
  authForm: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: 10
  },
  authFormInput: {
    marginBottom: 10
  }
});

export default styles;
