<?

require_once('db.php');
require_once('auth.php');
require_once('permission.php');
