import { connect } from 'react-redux';

import { requestUserData } from 'store/user/actions';
import { getUser } from 'store/user/selectors';

import Profile from '../component/Profile';

const mapStateToProps = ({ user }) => ({
  user: getUser(user)
});

const mapDispatchToProps = dispatch => ({
  requestUserData: userId => dispatch(requestUserData(userId))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Profile);
