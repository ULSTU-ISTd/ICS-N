import axios from 'axios';

class ApiClient {
  constructor() {
    this.apiUrl = 'http://localhost:3102/';
  }

  async get(url) {
    const { data, error } = await axios.get(`${this.apiUrl}${url}`);

    if (error) {
      return {
        data: null,
        error
      };
    }

    return {
      data: data.data,
      error: null
    };
  }

  async post(url, body) {
    const { data, error } = await axios.post(`${this.apiUrl}${url}`, body);

    if (error) {
      return {
        data: null,
        error
      };
    }

    return {
      data: data.data,
      error: null
    };
  }
}

const apiClient = new ApiClient();

export default apiClient;
