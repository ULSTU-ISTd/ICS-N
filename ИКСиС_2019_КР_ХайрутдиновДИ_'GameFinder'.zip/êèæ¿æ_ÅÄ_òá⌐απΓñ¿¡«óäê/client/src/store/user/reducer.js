import {
  LOGIN,
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  REGISTER,
  REGISTER_SUCCESS,
  REGISTER_FAIL,
  REQUEST_USER_DATA_SUCCESS
} from './constants';

const initialState = {
  userId: '',
  user: {}
};

const handlers = {
  [LOGIN]: state => ({ ...state }),
  [LOGIN_SUCCESS]: (state, { userId }) => ({ ...state, userId }),
  [LOGIN_FAIL]: state => ({ ...state }),
  [REGISTER]: state => ({ ...state }),
  [REGISTER_SUCCESS]: (state, { userId }) => ({ ...state, userId }),
  [REGISTER_FAIL]: state => ({ ...state }),
  [REQUEST_USER_DATA_SUCCESS]: (state, { user }) => ({ ...state, user })
};

const reducer = (state = initialState, action) => {
  const handler = handlers[action.type];

  if (handler) {
    return handler(state, action);
  }
  return state;
};

export default reducer;
