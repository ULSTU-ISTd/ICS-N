import React, { Component } from 'react';

import { withStyles } from '@material-ui/core/styles';

import GamesContainer from 'components/GamesContainer';
import ButtonsPanel from 'components/ButtonsPanel';
import GameUpload from 'components/GameUpload';

import styles from './styles';

class Main extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isGameUploadVisible: false
    };

    this.showGameUpload = this.showGameUpload.bind(this);
    this.hideGameUpload = this.hideGameUpload.bind(this);
  }

  componentDidMount() {
    const { getGames } = this.props;

    getGames();
  }

  showGameUpload() {
    this.setState({ isGameUploadVisible: true });
  }

  hideGameUpload() {
    this.setState({ isGameUploadVisible: false });
  }

  render() {
    const { games } = this.props;
    const { isGameUploadVisible } = this.state;

    return (
      <>
        <h1>Игры</h1>
        <GamesContainer games={games} />
        {isGameUploadVisible ? (
          <GameUpload hideGameUpload={this.hideGameUpload} />
        ) : null}
        <ButtonsPanel showGameUpload={this.showGameUpload} />
      </>
    );
  }
}

export default withStyles(styles)(Main);
