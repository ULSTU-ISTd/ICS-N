<?
?><!DOCTYPE html>
<!-- saved from url=(0038)http://bootstrap-3.ru/examples/signin/ -->
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="shortcut icon" href="images/pomodoro-time-icon.png">
  <title>Manager Sign in</title>
  <!-- Bootstrap core CSS -->
  <link href="./css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="./css/signin.css" rel="stylesheet">
</head>

  <body>
    <div class="container">
      <form class="form-signin" role="form" method="POST" action="http://tasks.ru/php/login.php">
        <h2 class="form-signin-heading">Please sign in</h2>
        <input type="text" placeholder="Login" name='username' class="form-control" required autofocus>
        <input type="password" placeholder="Password" name='password' class="form-control"  required>
        <button class="btn btn-lg btn-primary btn-block" id="login"  name='login' type="submit">Sign in</button>
      </form>

    </div>
      </body></html>
