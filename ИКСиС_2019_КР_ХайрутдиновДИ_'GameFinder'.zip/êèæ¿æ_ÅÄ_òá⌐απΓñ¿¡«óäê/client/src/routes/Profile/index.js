import Profile from './container/Profile';

export default Profile;
