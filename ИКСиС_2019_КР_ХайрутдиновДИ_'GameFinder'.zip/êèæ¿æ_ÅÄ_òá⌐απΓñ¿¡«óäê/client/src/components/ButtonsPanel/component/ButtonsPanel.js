import React from 'react';

import Paper from '@material-ui/core/Paper';
import AddComment from '@material-ui/icons/AddComment';
import { withStyles } from '@material-ui/core/styles';

import Button from 'components/Button';

import { isUserIdPresence } from 'helpers/localStorage';

import styles from './styles';

const ButtonsPanel = ({ classes, showGameUpload }) => {
  const isUserLoggedIn = isUserIdPresence();

  if (!isUserLoggedIn) {
    return null;
  }

  return (
    <div className={classes.buttonsPanel}>
      <Button onClick={showGameUpload}>
        <AddComment />
      </Button>
    </div>
  );
};

export default withStyles(styles)(ButtonsPanel);
