﻿namespace KNB
{
    partial class App
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.radio_server = new System.Windows.Forms.RadioButton();
            this.radio_client = new System.Windows.Forms.RadioButton();
            this.text_ip = new System.Windows.Forms.TextBox();
            this.button_start = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label_stat = new System.Windows.Forms.Label();
            this.text_debug = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // radio_server
            // 
            this.radio_server.AutoSize = true;
            this.radio_server.Location = new System.Drawing.Point(12, 35);
            this.radio_server.Name = "radio_server";
            this.radio_server.Size = new System.Drawing.Size(62, 17);
            this.radio_server.TabIndex = 0;
            this.radio_server.TabStop = true;
            this.radio_server.Text = "Сервер";
            this.radio_server.UseVisualStyleBackColor = true;
            // 
            // radio_client
            // 
            this.radio_client.AutoSize = true;
            this.radio_client.Location = new System.Drawing.Point(12, 58);
            this.radio_client.Name = "radio_client";
            this.radio_client.Size = new System.Drawing.Size(61, 17);
            this.radio_client.TabIndex = 1;
            this.radio_client.TabStop = true;
            this.radio_client.Text = "Клиент";
            this.radio_client.UseVisualStyleBackColor = true;
            // 
            // text_ip
            // 
            this.text_ip.Location = new System.Drawing.Point(12, 92);
            this.text_ip.Name = "text_ip";
            this.text_ip.Size = new System.Drawing.Size(98, 20);
            this.text_ip.TabIndex = 2;
            this.text_ip.Text = "127.0.0.1";
            this.text_ip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_start
            // 
            this.button_start.Location = new System.Drawing.Point(25, 127);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(75, 23);
            this.button_start.TabIndex = 3;
            this.button_start.Text = "Запуск";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(180, 35);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Камень";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(180, 75);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(97, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Ножницы";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(180, 113);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(97, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "Бумага";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label_stat
            // 
            this.label_stat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label_stat.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_stat.Location = new System.Drawing.Point(177, 155);
            this.label_stat.Name = "label_stat";
            this.label_stat.Size = new System.Drawing.Size(100, 23);
            this.label_stat.TabIndex = 7;
            this.label_stat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_debug
            // 
            this.text_debug.Location = new System.Drawing.Point(12, 218);
            this.text_debug.Multiline = true;
            this.text_debug.Name = "text_debug";
            this.text_debug.Size = new System.Drawing.Size(265, 85);
            this.text_debug.TabIndex = 8;
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 194);
            this.Controls.Add(this.text_debug);
            this.Controls.Add(this.label_stat);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.text_ip);
            this.Controls.Add(this.radio_client);
            this.Controls.Add(this.radio_server);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "КНБ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radio_server;
        private System.Windows.Forms.RadioButton radio_client;
        private System.Windows.Forms.TextBox text_ip;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label_stat;
        private System.Windows.Forms.TextBox text_debug;
        private System.Windows.Forms.Timer timer;
    }
}

