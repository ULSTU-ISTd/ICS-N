/* */ 
module.exports = { "default": require("core-js/library/fn/number/is-safe-integer"), __esModule: true };