<?
	if (isset($_COOKIE['AUTH']))
	{
		setcookie("AUTH","false",time()-1);
	    setcookie("login");
	    setcookie("password");
	}
	header('Location: /index.php');
	exit;
?>
