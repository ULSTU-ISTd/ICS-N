import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import Chart from 'chart.js';

import Grid from '@material-ui/core/Grid';

import { getUserId, removeUserId } from 'helpers/localStorage';

import Review from 'components/Review';
import Button from 'components/Button';

const weekdays = [
  'sunday',
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday'
];

class Profile extends Component {
  constructor(props) {
    super(props);

    this.state = {
      login: '',
      reviews: []
    };

    this.chartRef = React.createRef();
  }

  componentDidMount() {
    const { requestUserData } = this.props;
    const userId = getUserId();

    requestUserData(userId);
  }

  componentWillReceiveProps(newProps) {
    const { user } = newProps;
    const { login, reviews } = user;

    this.setState({
      login: login || '',
      reviews: reviews || []
    });

    if (reviews.length === 0) {
      return;
    }

    const chartContext = this.chartRef.current;
    const initialReviewsPerDay = new Array(7).fill(0);

    const reviewsPerDay = reviews.reduce((prev, curr) => {
      const day = new Date(curr.uploadTime).getDay();

      prev[day] += 1;
      return prev;
    }, initialReviewsPerDay);

    new Chart(chartContext, {
      type: 'line',
      data: {
        datasets: [{ data: reviewsPerDay }],
        labels: weekdays
      },
      options: {
        legend: {
          display: false
        },
        title: {
          display: true,
          text: 'Активность за последнюю неделю'
        }
      }
    });
  }

  render() {
    const { login } = this.state;
    const {
      user: { reviews }
    } = this.props;

    return (
      <>
        <h1>{login}</h1>
        <Grid container>
          <Grid item xs={8}>
            {reviews &&
              reviews.map(review => (
                <Review
                  key={review._id}
                  author={login}
                  gameName={review.game.name}
                  review={review}
                />
              ))}
          </Grid>
          <Grid item xs={4}>
            <div style={{ maxHeight: 500 }}>
              <canvas ref={this.chartRef} />
            </div>
            <Button
              onClick={() => {
                localStorage.removeItem('admin');
                removeUserId();
                this.props.history.push('/');
              }}
            >
              Выйти
            </Button>
          </Grid>
        </Grid>
      </>
    );
  }
}

export default withRouter(Profile);
