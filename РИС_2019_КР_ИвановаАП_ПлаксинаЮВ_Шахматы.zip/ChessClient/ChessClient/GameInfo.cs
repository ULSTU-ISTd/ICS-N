﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace ChessClient
{
    public struct GameInfo
    {
        public int ID;
        public string FEN;
        public string Status;
        public string LastMove;
        public bool Shah;
        public string Winner;

        public GameInfo(NameValueCollection list)
        {
            ID = int.Parse(list["ID"]);
            FEN = list["FEN"];
            Status = list["Status"];
            LastMove = list["LastMove"];
            Shah = bool.Parse(list["Shah"]);
            Winner = list["Winner"];
        }

        override
            public string ToString() =>
            "ID =" + ID +
            "\nFEN =" + FEN +
            "\nStatus =" + Status +
            "\nLastMove =" + LastMove +
            "\nShah =" + Shah +
            "\nWinner =" + Winner;

    }
}
