import React from 'react';
import { Switch, Route } from 'react-router-dom';

import { withStyles } from '@material-ui/core/styles';

import Main from 'routes/Main';
import Auth from 'routes/Auth';
import Profile from 'routes/Profile';
import Categories from 'routes/Categories';
import Search from 'routes/Search';
import Game from 'routes/Game';

import AppHeader from 'components/AppHeader';
import ErrorBoundary from 'containers/ErrorBoundary';

import checkAuth from 'utils/checkAuth';

import styles from './styles';
import 'styles/general.scss';
import 'styles/normalize.scss';

const App = ({ classes }) => (
  <div className='page'>
    <AppHeader />
    <main className={classes.main}>
      <ErrorBoundary>
        <Switch>
          <Route component={checkAuth(Profile)} path='/profile' />
          <Route component={Auth} path='/auth' />
          <Route component={Categories} path='/categories' />
          <Route component={Search} path='/searches' />
          <Route component={Game} path='/game/:gameId' />
          <Route component={Main} path='/' />
        </Switch>
      </ErrorBoundary>
    </main>
    <footer />
  </div>
);

export default withStyles(styles)(App);
