// Add list tasks for popup
function listTask() {
  html="";
  for (let i = 0; i < Data.tasks.length; i++) {
    if ( Data.tasks[i].Type==127) continue;
    html += '<div class="tasks-box__login">';
    html += '<input type="radio" id = "'+i+'" value = "'+Data.tasks[i].ID+'">';
    html += '<label for="'+i+'">'+Data.tasks[i].Name+'</label>';
    html += '</div>';
  }
  document.getElementById('tasks_box').innerHTML = html;
  selectTask();
}

// Add list message
function listMessage() {
  var html="";
  for (let i = 0; i < Data.message.length; i++) {
    html += '<li class="left clearfix"><div class="header"><strong class="primary-font">';
    html += Data.message[i].Name;
    html += '</strong><small class="pull-right text-muted">';
    html += Data.message[i].TimeSend;
    html += '</small></div><p>';
    html += Data.message[i].SMS;
    html += '</p></li>';
  }
  document.getElementById('message_box').innerHTML = html;
}
//after click on the radio-button happen event, where checked Task text and his id store in local
function selectTask() {
  $('input[type=radio]').click(function() {
    if($(this).is(':checked')) {
      localStorage['Task_Text'] =  Data.tasks[this.id].Text;
      localStorage['Task_ID'] = this.value;
    } else {
    }
  });
}

function refresh() {
  //Назначение обработчиков сразу после выполнения запроса,
  // И запомнить объект jqXHR для этого запроса
$.ajax( "http://tasks.ru/pomodoro/php/refresh.php")
  .done(function( jdata ) {
    //let data =  JSON.parse(jdata);
    Data = JSON.parse(jdata);
    listMessage();
    listTask();
  });
};

///////////
// Update time timer
function UpdateLayout() {
  document.getElementById('timer_box').innerHTML = Counter();
  if (localStorage["Type"] =='alarm') { // Don't WORK TIME
    document.getElementById('timer').classList.remove('timer-active');
    refresh();
  } else {
    $("#timer_message").html(localStorage["Task_Text"]);
      document.getElementById('timer').classList.add('timer-active');
  }
}
