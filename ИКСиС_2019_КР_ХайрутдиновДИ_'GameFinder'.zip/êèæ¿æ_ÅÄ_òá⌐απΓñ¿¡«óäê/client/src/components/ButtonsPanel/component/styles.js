import { LIGHT_GREEN } from 'styles/colors';

const styles = () => ({
  buttonsPanel: {
    position: 'fixed',
    bottom: 15,
    right: 15,
    background: LIGHT_GREEN
  }
});

export default styles;
