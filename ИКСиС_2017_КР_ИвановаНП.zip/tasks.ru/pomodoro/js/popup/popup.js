'use strict'
var Data;
var UserID=[];
var k=0;
/********* посылаем данные на окно "Сообщения" с текстом сообщения****************/
button.onclick = function () {
  // alert({ type: 'sendMessage', message: text.value });
  $.post("http://tasks.ru/pomodoro/php/message.php", { type: 'sendMessage', message: text.value });
  // .done(function(data) {
  //   alert(data);
  // });
  text.value='';
}

section_message.onclick = function (e) {
  document.getElementById('tasks').classList.remove('active');
  document.getElementById('message').classList.add('active');
};
section_tasks.onclick = function (e) {
  document.getElementById('tasks').classList.add('active');
  document.getElementById('message').classList.remove('active');
};

UpdateLayout();

  // document.getElementById('container').classList.add('container-active');
  //   document.getElementById('timer').classList.remove('timer-active');
  //     document.getElementById('tasks').classList.remove('active');
  //     document.getElementById('message').classList.remove('active');
setInterval(()=> {
  UpdateLayout();
},1000);
