import React from 'react';
import { Link } from 'react-router-dom';

import { withStyles } from '@material-ui/core/styles';

import avatar from '../../../assets/defaultAvatar.svg';
import styles from './styles';

const UserAvatar = ({ classes }) => (
  <div className={classes.avatarWrap}>
    <Link to={{ pathname: '/profile' }}>
      <img className={classes.avatar} src={avatar} />
    </Link>
  </div>
);

export default withStyles(styles)(UserAvatar);
