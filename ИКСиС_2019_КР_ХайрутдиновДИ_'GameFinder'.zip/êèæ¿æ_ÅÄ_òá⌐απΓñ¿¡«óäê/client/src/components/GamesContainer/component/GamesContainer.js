import React from 'react';

import { withStyles } from '@material-ui/core/styles';

import GameTab from 'components/GameTab';

import styles from './styles';

const Games = ({ classes, games }) => (
  <div className={classes.gamesContainer}>
    {games.map(({ url, _id, name }) => (
      <GameTab key={_id} gameId={_id} url={url} name={name} />
    ))}
  </div>
);

export default withStyles(styles)(Games);
