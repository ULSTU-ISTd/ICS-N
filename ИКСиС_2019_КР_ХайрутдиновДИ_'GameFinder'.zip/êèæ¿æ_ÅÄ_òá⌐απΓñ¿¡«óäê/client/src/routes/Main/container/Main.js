import { connect } from 'react-redux';

import { selectGames } from 'store/game/selectors';
import { getGames } from 'store/game/actions';

import Main from '../component/Main';

const mapStateToProps = ({ game }) => ({
  games: selectGames(game)
});

const mapDispatchToProps = dispatch => ({
  getGames: () => dispatch(getGames())
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Main);
