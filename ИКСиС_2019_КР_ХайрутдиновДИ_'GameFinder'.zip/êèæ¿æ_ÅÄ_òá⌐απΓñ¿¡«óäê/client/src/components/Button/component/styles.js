import { DARK_GREEN, LIGHT_GREEN } from 'styles/colors';

const styles = () => ({
  button: {
    width: 'calc(100% - 20px)',
    maxWidth: 200,
    margin: 10,
    border: `1px solid ${DARK_GREEN}`,
    background: DARK_GREEN,
    color: LIGHT_GREEN,
    transition: 'all .5s ease',
    '&:hover': {
      color: DARK_GREEN,
      background: LIGHT_GREEN
    }
  },
  activeButton: {
    color: DARK_GREEN,
    background: LIGHT_GREEN,
  }
});

export default styles;
