/* */ 
module.exports = { "default": require("core-js/library/fn/array/last-index-of"), __esModule: true };