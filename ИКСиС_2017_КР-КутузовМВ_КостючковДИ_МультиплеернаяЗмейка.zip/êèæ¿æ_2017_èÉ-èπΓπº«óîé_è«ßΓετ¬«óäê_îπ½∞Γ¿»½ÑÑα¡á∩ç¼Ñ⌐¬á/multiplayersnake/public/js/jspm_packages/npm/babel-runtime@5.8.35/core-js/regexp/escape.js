/* */ 
module.exports = { "default": require("core-js/library/fn/regexp/escape"), __esModule: true };