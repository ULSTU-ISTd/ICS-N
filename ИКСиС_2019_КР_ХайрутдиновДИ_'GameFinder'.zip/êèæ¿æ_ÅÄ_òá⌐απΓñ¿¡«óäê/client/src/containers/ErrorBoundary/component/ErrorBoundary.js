import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

import Button from '@material-ui/core/Button';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);

    this.state = { hasError: false };

    this.handleClick = this.handleClick.bind(this);
  }

  componentDidCatch(error) {
    this.setState({ hasError: true });
  }

  handleClick() {
    const { history } = this.props;

    this.setState({ hasError: false }, () => {
      history.push('/');
    });
  }

  render() {
    const { hasError } = this.state;

    if (hasError) {
      return (
        <div>
          <h1>Something went wrong.</h1>
          <Button onClick={this.handleClick}>На главную</Button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default withRouter(ErrorBoundary);
