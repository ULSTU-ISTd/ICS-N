import { connect } from 'react-redux';

import { search, queryPopularSearches } from 'store/search/actions';
import { getSearches, getLastSearchGames } from 'store/search/selectors';

import Search from '../component/Search';

const mapStateToProps = ({ search }) => ({
  searches: getSearches(search),
  lastSearchGames: getLastSearchGames(search)
});

const mapDispatchToProps = dispatch => ({
  search: value => dispatch(search(value)),
  queryPopularSearches: () => dispatch(queryPopularSearches())
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Search);
