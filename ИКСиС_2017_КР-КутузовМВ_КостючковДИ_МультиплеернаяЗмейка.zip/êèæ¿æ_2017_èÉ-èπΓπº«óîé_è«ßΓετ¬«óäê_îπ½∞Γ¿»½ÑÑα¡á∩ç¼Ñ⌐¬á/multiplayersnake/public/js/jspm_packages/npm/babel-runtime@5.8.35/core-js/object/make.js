/* */ 
module.exports = { "default": require("core-js/library/fn/object/make"), __esModule: true };