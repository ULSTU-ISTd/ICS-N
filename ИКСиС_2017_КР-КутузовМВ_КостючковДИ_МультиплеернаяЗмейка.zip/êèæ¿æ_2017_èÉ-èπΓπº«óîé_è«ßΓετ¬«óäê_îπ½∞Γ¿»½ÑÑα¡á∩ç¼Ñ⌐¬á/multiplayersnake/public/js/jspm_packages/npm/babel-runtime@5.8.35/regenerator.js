/* */ 
module.exports = require('./regenerator/index');
