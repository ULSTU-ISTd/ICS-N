import reviews from './reviews';
import categories from './categories';
import user from './user';
import search from './search';
import games from './games';

export default {
  categories,
  reviews,
  user,
  games,
  search
};
