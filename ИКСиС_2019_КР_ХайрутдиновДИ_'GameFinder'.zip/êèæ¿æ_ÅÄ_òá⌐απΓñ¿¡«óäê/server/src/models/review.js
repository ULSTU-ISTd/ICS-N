import { Schema, model } from 'mongoose';

const reviewSchema = Schema({
  _id: Schema.Types.ObjectId,
  title: { type: String, required: true },
  review: { type: String, required: true },
  uploadTime: { type: Number },
  game: { type: Schema.Types.ObjectId, required: true, ref: 'Game' },
  author: { type: Schema.Types.ObjectId, required: true, ref: 'User' }
});

const Review = model('Review', reviewSchema);

export default Review;
