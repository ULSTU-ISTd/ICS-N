import Game from './container/Game';

export default Game;