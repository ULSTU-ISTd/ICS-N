import React, { Component } from 'react';
import { Redirect } from 'react-router-dom';

import { getUserId } from 'helpers/localStorage';

function checkAuth(WrappedComponent) {
  return class extends Component {
    isUserLoggedIn() {
      const userId = getUserId();

      if (userId) {
        return true;
      }
      return false;
    }

    render() {
      return this.isUserLoggedIn() ? (
        <WrappedComponent {...this.props} />
      ) : (
        <Redirect to='/auth' />
      );
    }
  };
}

export default checkAuth;
