			<div class="menu-left-center">
				<div class="left-menu-block">
					<p class="left-menu-title">Мужские аксессуары</p>
						<ul>
									<?php
			
				$result = mysql_query("SELECT * FROM category WHERE type='МужскиеАксессуары'",$link);
				
				if (mysql_num_rows($result) > 0)
				{
					$row = mysql_fetch_array($result);
					
					do
					{
						echo '
						
						<li class="sort-item"><a href="view_cat.php?cat='.strtolower($row["brand"]).'&type='.$row["type"].'">'.$row["brand"].'</a></li>
						
						';
						
						
						
						
					}
					while ($row = mysql_fetch_array($result));
				}
			
			?>
						</ul>
					<p class="left-menu-title">Женские аксессуары</p>
						<ul>
									<?php
			
				$result = mysql_query("SELECT * FROM category WHERE type='ЖенскиеАксессуары'",$link);
				
				if (mysql_num_rows($result) > 0)
				{
					$row = mysql_fetch_array($result);
					
					do
					{
						echo '
						
						<li class="sort-item"><a href="view_cat.php?cat='.strtolower($row["brand"]).'&type='.$row["type"].'">'.$row["brand"].'</a></li>
						
						';
						
						
						
						
					}
					while ($row = mysql_fetch_array($result));
				}
			
			?>
						</ul>
					<p class="left-menu-title">Аксессуары для автомобилей</p>
						<ul>
			<?php
			
				$result = mysql_query("SELECT * FROM category WHERE type='АвтомобильныеАксессуары'",$link);
				
				if (mysql_num_rows($result) > 0)
				{
					$row = mysql_fetch_array($result);
					
					do
					{
						echo '
						
						<li class="sort-item"><a href="view_cat.php?cat='.strtolower($row["brand"]).'&type='.$row["type"].'">'.$row["brand"].'</a></li>
						
						';
						
						
						
						
					}
					while ($row = mysql_fetch_array($result));
				}
			
			?>
						</ul>
					

				</div>
			</div>