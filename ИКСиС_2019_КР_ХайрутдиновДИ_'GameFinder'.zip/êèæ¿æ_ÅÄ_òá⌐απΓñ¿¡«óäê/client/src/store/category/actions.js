import apiClient from 'utils/apiClient';
import {
  QUERY_CATEGORIES,
  QUERY_CATEGORIES_SUCCESS,
  QUERY_CATEGORIES_ERROR,
  QUERY_CATEGORY,
  QUERY_CATEGORY_SUCCESS,
  QUERY_CATEGORY_ERROR
} from './constants';

export const queryCategories = () => {
  return dispatch => {
    dispatch({ type: QUERY_CATEGORIES });

    apiClient.get('categories').then(({ data, error }) => {
      if (error) {
        dispatch({ type: QUERY_CATEGORIES_ERROR });
        return;
      }

      dispatch({
        type: QUERY_CATEGORIES_SUCCESS,
        categories: data.categories
      });
    });
  };
};

export const queryCategoryGames = categoryId => {
  return dispatch => {
    dispatch({ type: QUERY_CATEGORY });

    apiClient
      .get(`categories/${categoryId}`)
      .then(({ data: { category }, error }) => {
        if (error) {
          dispatch({ type: QUERY_CATEGORY_ERROR });
          return;
        }

        const { name, games } = category;

        dispatch({ type: QUERY_CATEGORY_SUCCESS, data: { name, games } });
      });
  };
};
