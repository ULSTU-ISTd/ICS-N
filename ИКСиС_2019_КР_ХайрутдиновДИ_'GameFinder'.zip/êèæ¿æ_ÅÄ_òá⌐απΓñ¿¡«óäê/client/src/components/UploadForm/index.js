import UploadForm from './container/UploadForm';

export default UploadForm;
