const styles = () => ({
  form: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center'
  }
});

export default styles;