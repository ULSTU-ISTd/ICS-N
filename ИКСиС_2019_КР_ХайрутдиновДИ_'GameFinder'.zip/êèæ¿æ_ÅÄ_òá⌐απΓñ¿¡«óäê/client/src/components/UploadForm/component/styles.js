import { LIGHT_GREEN, DARK_GREEN } from 'styles/colors';

const styles = () => ({
  formWrap: {
    margin: 'auto',
    maxHeight: 700
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    padding: '10px 20px',
    width: 400
  },
  formInput: {
    display: 'flex',
    flexDirection: 'column',
    marginBottom: 10
  },
  inputTitle: {
    textAlign: 'left',
    fontSize: 16,
    fontWeight: 'bold'
  },
  textField: {
    marginTop: 0
  },
  submitButtonWrap: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center'
  },
  radioWrap: {
    display: 'flex',
    flexDirection: 'row',
    cursor: 'pointer',
    marginTop: 5
  },
  radio: {
    display: 'none',
    '&:checked ~ div': {
      background: DARK_GREEN
    }
  },
  customRadio: {
    height: 12,
    width: 12,
    marginRight: 5,
    background: LIGHT_GREEN,
    border: `2px solid ${DARK_GREEN}`
  }
});

export default styles;
