<?
$permission = 2;
require_once 'core/main.php';
//require_once ('/bd.php');
?>
	  <h3>Add new task</h3>
		<form action="add.php?add=true" class="form-signin" method="POST">
		  <input type="text" name="Name" class="form-control" placeholder="Название проблемы" value="<?=$clients_row['Name']?>"><br />
	    <input type="text" name="Text" class="form-control" placeholder="Описание проблемы" value="<?=$clients_row['Text']?>"><br />
			<button type="submit" name="action" class="btn btn-lg btn-primary btn-block">Add</button>
		</form>
<?
if ($_GET['add'] == "true") {
	$result_add=$mysqli->query("INSERT INTO Tasks (ID,Name,Text)
	VALUES ('".$_POST['ID']."' ,'".$_POST['Name']."' ,'".$_POST['Text']."')");
	if ($result_add==true)//удалось изменить данные, запрос прошел
			 header("location: ./dashboard.php");//переадресовать на главную страницу
	else header( 'Refresh: 0; url=/error.html' ); // переадресовать на страницу ошибки немедленно (без задержки).
}
