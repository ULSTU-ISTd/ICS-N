import GamesContainer from './component/GamesContainer';

export default GamesContainer;