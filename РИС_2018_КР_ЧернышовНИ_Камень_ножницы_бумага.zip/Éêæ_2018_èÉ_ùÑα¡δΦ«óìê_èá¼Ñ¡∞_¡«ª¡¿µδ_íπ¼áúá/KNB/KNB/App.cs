﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace KNB
{
    public partial class App : Form
    {
        int port = 12345;
        //потоки для отправки и получения фигуры
        StreamReader reader;
        StreamWriter writer;
        bool sent_hand = false;
        bool read_hand = false;
        string my_hand = "";
        string op_hand = "";

        public App()
        {
            InitializeComponent();
            setButtons(false);
        }

        //деактивция кнопок игры до момента соединения
        private void setButtons(bool enable)
        {
            button1.Enabled = enable;
            button2.Enabled = enable;
            button3.Enabled = enable;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_start_Click(object sender, EventArgs e)
        {
            if (radio_server.Checked)
                StartServer();
            if (radio_client.Checked)
                StartClient();
            setButtons(true);
            timer.Enabled = true;
        }

        private void StartServer()
        {
            TcpListener listener = new TcpListener(new IPEndPoint(IPAddress.Parse(text_ip.Text), port));
            listener.Start();
            //программа заработает только после подключения клиента
            TcpClient server = listener.AcceptTcpClient();
            //чтобы не зацикливалось
            server.ReceiveTimeout = 50;
            reader = new StreamReader(server.GetStream());
            writer = new StreamWriter(server.GetStream());
            writer.AutoFlush = true;
        }

        private void StartClient()
        {
            TcpClient client = new TcpClient();
            client.Connect(text_ip.Text, port);
            //чтобы не зацикливалось
            client.ReceiveTimeout = 50;
            reader = new StreamReader(client.GetStream());
            writer = new StreamWriter(client.GetStream());
            writer.AutoFlush = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            send("K");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            send("N");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            send("B");
        }

        private void send(string text)
        {
            if (sent_hand) return;
            writer.WriteLine(text);
            sent_hand = true;
            my_hand = text;
            setButtons(false);
            text_debug.Text += "send " + text + Environment.NewLine;
        }

        private string read()
        {
            if (read_hand) return "";
            try
            {
                string text;
                text = reader.ReadLine();
                read_hand = true;
                op_hand = text;
                return text;
            }
            catch
            {
                return "";
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            text_debug.Text = "sent_hand = " + sent_hand.ToString() + Environment.NewLine +
                              "read_hand = " + sent_hand.ToString() + Environment.NewLine +
                              "my_hand = " + my_hand + Environment.NewLine +
                              "op_hand = " + op_hand;
            string hand = read();
            if (sent_hand && read_hand)
                FinishGame();
        }

        private void FinishGame()
        {
            int ch = CompareHands(my_hand, op_hand);
            string res = "";
            if (ch == 0) res = "Ничья";
            if (ch == 1) res = "Победа";
            if (ch == 2) res = "Проигрыш";

            label_stat.Text = res;
            sent_hand = false;
            read_hand = false;
            setButtons(true);
            my_hand = "";
            op_hand = "";
        } 

        private int CompareHands(string hand1, string hand2)
        {
            if (hand1 == hand2) return 0;
            if (hand1 == "K")
                if (hand2 == "N")
                    return 1;
                else
                    return 2;
            if (hand1 == "N")
                if (hand2 == "B")
                    return 1;
                else
                    return 2;
            if (hand1 == "B")
                if (hand2 == "N")
                    return 1;
                else
                    return 2;
            return 0;
        }
    }
}