/* */ 
require('../modules/es7.string.at');
require('../modules/es7.string.pad-left');
require('../modules/es7.string.pad-right');
require('../modules/es7.string.trim-left');
require('../modules/es7.string.trim-right');
module.exports = require('../modules/$.core').String;
