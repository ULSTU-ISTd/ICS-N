import game from './reducer';

export default game;