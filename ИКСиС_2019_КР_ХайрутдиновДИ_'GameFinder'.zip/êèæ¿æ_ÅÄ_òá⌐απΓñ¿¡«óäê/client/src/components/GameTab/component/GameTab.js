import React from 'react';
import { Link } from 'react-router-dom';

import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';

import tempImage from '../../../assets/temp.jpg';

import styles from './styles';

const GameTab = ({ url, gameId, name, classes }) => {
  return (
    <div className={classes.gameTab}>
      <img src={url || tempImage} className={classes.gameTabImage} />
      <Button
        className={classes.gameButton}
        variant="contained"
        component={Link}
        to={`/game/${gameId}`}
      >
        {name}
      </Button>
    </div>
  );
};

export default withStyles(styles)(GameTab);
