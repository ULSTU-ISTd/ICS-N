import Main from './container/Main';

export default Main;
