export const getUserId = state => state.userId;
export const getUser = state => state.user;