import Button from './component/Button';

export default Button;