import Auth from './container/Auth';

export default Auth;
