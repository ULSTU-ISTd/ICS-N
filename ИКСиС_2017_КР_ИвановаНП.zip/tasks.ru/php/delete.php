<?
$permission = 2;
require_once 'core/main.php';
// require_once ('/bd.php');
?>
<h3>Delete task</h3>
<form action="delete.php?delete=true&id=<?=$_GET['id']?>" class="form-signin" method="POST">
<label>Now task #<?=$_GET['id']?> will exterminate </label> 	<h1></h1>
<button type="submit" name="action" class="btn btn-lg btn-primary btn-block">Delete</button>
</form>
<?
if($_GET['delete'] == "true") {//данные из формы 'delete' получены
	$sqlquery=$mysqli->query("DELETE FROM Tasks WHERE ID='". $_GET['id']."'");
	if ($sqlquery==true)
		header("location: ./dashboard.php");
	else header( 'Refresh: 0; url=/error.html' ); // переадресовать на страницу ошибки немедленно (без задержки).
}
