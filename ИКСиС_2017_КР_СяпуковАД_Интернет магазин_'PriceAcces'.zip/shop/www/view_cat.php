<?php
    session_start();
	include("/functions/functions.php");

	
	$cat = $_GET["cat"];
		$cat = strip_tags($cat);
		$cat = mysql_real_escape_string($cat);
		$cat = trim($cat);
	$type = $_GET["type"];
		$type = strip_tags($type);
		$type = mysql_real_escape_string($type);
		$type = trim($type);
	
	$sorting = $_GET["sort"];
	
	switch($sorting)
	{
		case 'no-sort';
		$sorting = 'product_id DESC';
		$sort_name = 'Нет сортировки';
		break;
		
		case 'price-up';
		$sorting = 'price ASC';
		$sort_name = 'По возрастанию';
		break;
		
		case 'price-down';
		$sorting = 'price DESC';
		$sort_name = 'По убыванию';
		break;
		
		case 'new';
		$sorting = 'datetime DESC';
		$sort_name = 'Новинки';
		break;
		
		case 'popular';
		$sorting = 'count';
		$sort_name = 'Популярное DESC';
		break;
		
		default:
		$sorting = 'product_id DESC';
		$sort_name = 'Нет сортировки';
		break;
		
	}
	
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Интернет-магазин</title>
<link rel="stylesheet" href="/css/style.css">

    <script type="text/javascript" src="/js/jquery-1.8.2.min.js"></script> 
    <script type="text/javascript" src="/js/jcarousellite_1.0.1.js"></script> 
    <script type="text/javascript" src="/js/shop-script.js"></script>
    <script type="text/javascript" src="/js/jquery.cookie.min.js"></script>
    <script type="text/javascript" src="/trackbar/jquery.trackbar.js"></script>
    
    <script type="text/javascript" src="/js/jquery.form.js"></script>
    <script type="text/javascript" src="/js/jquery.validate.js"></script>  
    <script type="text/javascript" src="/js/TextChange.js"></script>  
</head>
<body>
<?php
	include("/include/db_connect.php");
	include("/include/block-header.php");
?>
	
	<div class="block-center">
		<div class="centercont">
			<?php
				include("/include/menu-left.php");
			?>
			<div class="block-content">	


			<?php
			
				if (!empty($cat) && !empty($type))
				{
					
					$querycat = "brand ='$cat' AND type_product='$type'";
					
					
				} else
				{
					if(!empty($type))
					{
						$querycat = "type_product='$type'";
					} else
					{
						$querycat = "";
					}
				}
			
				$result = mysql_query("SELECT * FROM table_products WHERE $querycat ORDER BY $sorting",$link);
				
				if (mysql_num_rows($result) > 0)
				{
					$row = mysql_fetch_array($result);
					
					echo '
					
						<div class="block-top-center">
							<ul class="center-name-page">
								<li class="center-name-item"><a href="view_cat.php?cat='.$cat.'&type='.$type.'">Без сортировки</a></li>
								<li class="center-name-item"><a href="view_cat.php?cat='.$cat.'&type='.$type.'&sort=price-up">По возрастанию</a></li>
								<li class="center-name-item"><a href="view_cat.php?cat='.$cat.'&type='.$type.'&sort=price-down">По убыванию</a></li>
								<li class="center-name-item"><a href="view_cat.php?cat='.$cat.'&type='.$type.'&sort=new">Новинки</a></li>
								<li><a href="view_cat.php?cat='.$cat.'&type='.$type.'&sort=popular">Популярное</a></li>
								'.$sort_name.'
							</ul>
						</div>
					
					';
					
					do
					{
						if  (strlen($row["image"]) > 0 && file_exists("./product_img/".$row["image"]))
{
$img_path = './product_img/'.$row["image"];
$max_width = 280; 
$max_height = 280; 
 list($width, $height) = getimagesize($img_path); 
$ratioh = $max_height/$height; 
$ratiow = $max_width/$width; 
$ratio = min($ratioh, $ratiow); 
 
$width = intval($ratio*$width); 
$height = intval($ratio*$height);    
}else
{
$img_path = "/images/noimages.jpeg";
$width = 150;
$height = 125;
} 
						echo '
						
						<div class="block-product">
						<div class="block-product-img" align="center">
						<img src="'.$img_path.'" width="'.$width.'" height="'.$height.'" />
						</div>
						<div class="block-descrip-product">
						<p class="title-product">'.$row["title"].'</p>
						<div class="block-price-cart">
						<p class="price">'.group_numerals($row["price"]).'<a class="price_valiut">р.</a></p><a tid="'.$row["product_id"].'" class="cart-button"><img src="/img/carts.png" width="110" height="35"></a>
						</div>
						</div>
						</div>
						
						';
						
						
						
						
					}
					while ($row = mysql_fetch_array($result));
				} else
				{
					echo '<h1>Товары в категории отсутствуют</h1>';
				}
			
			?>
			</div>
			</div>
		</div>
	</div>

	
	
<?php
	include("/include/block-footer.php");
?>
</body>
</html>