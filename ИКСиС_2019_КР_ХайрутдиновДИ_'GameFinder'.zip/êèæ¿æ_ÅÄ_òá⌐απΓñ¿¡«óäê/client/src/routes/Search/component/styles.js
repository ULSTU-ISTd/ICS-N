const styles = () => ({
  popularSearches: {
    display: 'flex',
    flexDirection: 'row'
  },
  searchForm: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center'
  },
  searchesWrap: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center'
  }
});

export default styles;
