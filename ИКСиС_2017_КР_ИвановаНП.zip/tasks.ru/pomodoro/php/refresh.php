<?php
require_once('../../php/bd.php');
//вывод для оконки Сообщения
$query = $mysqli->query('SELECT `Messages`.*,`Users`.Name FROM `Messages`,`Users` WHERE `Messages`.FromID=`Users`.ID ORDER BY `Messages`.ID DESC');
while($rew = $query->fetch_assoc()) {
  $array['message'][]=$rew;
}
//вывод для оконки Задачи
$query = $mysqli->query('SELECT * FROM `Tasks` ORDER BY ID');//1 - online
while($rew = $query->fetch_assoc()) {
  $array['tasks'][]=$rew;// я непомню как объект делать)
  // в объект массивы сунуть
}
echo json_encode($array);//Конвертация данных в формат JSON
