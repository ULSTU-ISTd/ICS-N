import GameUpload from './component/GameUpload';

export default GameUpload;
