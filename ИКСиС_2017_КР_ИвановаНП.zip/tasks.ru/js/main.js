modal_close.onclick = function (e) {
  document.getElementById('modal').classList.remove('modal-active');
};

function Ajax(url) {
  document.getElementById('modal').classList.add('modal-active');
  // Загрузкa данных (HTTP-запросы к серверу без перезагрузки страницы)
  var xhr = new XMLHttpRequest();//Создаём новый объект XMLHttpRequest
  xhr.open('GET', url, false);// Конфигурируем его: GET-запрос на URL
  xhr.send();//Отсылаем запрос
  if (xhr.status != 200) {//Если код ответа сервера не 200, то это ошибка
    alert( xhr.status + ': ' + xhr.statusText );// обработать ошибку
  }
  else{
    //alert(xhr.responseText);// вывести результат
    document.getElementById('modal-view').innerHTML=xhr.responseText;
  }
}

try {
  var AG_onLoad=function(func){
    if(document.readyState==="complete"||document.readyState==="interactive")func();
    else if(document.addEventListener)document.addEventListener("DOMContentLoaded",func);
    else if(document.attachEvent)document.attachEvent("DOMContentLoaded",func)};
  var AG_removeElementById = function(id) { var element = document.getElementById(id); if (element && element.parentNode) { element.parentNode.removeChild(element); }};
  var AG_removeElementBySelector = function(selector) { if (!document.querySelectorAll) { return; } var nodes = document.querySelectorAll(selector); if (nodes) { for (var i = 0; i < nodes.length; i++) { if (nodes[i] && nodes[i].parentNode) { nodes[i].parentNode.removeChild(nodes[i]); } } } };
  var AG_each = function(selector, fn) { if (!document.querySelectorAll) return; var elements = document.querySelectorAll(selector); for (var i = 0; i < elements.length; i++) { fn(elements[i]); }; };
  var AG_removeParent = function(el, fn) { while (el && el.parentNode) { if (fn(el)) { el.parentNode.removeChild(el); return; } el = el.parentNode; } };
  var AdFox_getCodeScript = function() {};
  AG_onLoad(function() { AG_each('iframe[id^="AdFox_iframe_"]', function(el) { if (el && el.parentNode) { el.parentNode.removeChild(el); } }); });
  try { Object.defineProperty(window, 'noAdsAtAll', { get: function() { return true; } }); } catch (ex) {}
} catch (ex) { console.error('Error executing AG js: ' + ex); }
