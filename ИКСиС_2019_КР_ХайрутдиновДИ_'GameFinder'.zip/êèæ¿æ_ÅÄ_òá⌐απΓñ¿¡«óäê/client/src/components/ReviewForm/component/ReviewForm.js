import React from 'react';

import { withStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';

import Button from 'components/Button';

import { getUserId, isUserIdPresence } from 'helpers/localStorage';

import styles from './styles';

class ReviewForm extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      title: '',
      review: ''
    };

    this.handleInput = this.handleInput.bind(this);
    this.handleReviewAdd = this.handleReviewAdd.bind(this);
  }

  handleInput(field) {
    return event => {
      this.setState({ [field]: event.target.value });
    };
  }

  handleReviewAdd() {
    const { addReview, gameId } = this.props;
    const { title, review } = this.state;

    const authorId = getUserId();
    addReview(authorId, title, review, gameId);
  }

  render() {
    const { classes } = this.props;
    const { title, review } = this.state;
    const isUserAuthorized = isUserIdPresence();

    return (
      <Paper>
        {isUserAuthorized ? (
          <form className={classes.form}>
            <TextField
              value={title}
              onChange={this.handleInput('title')}
              placeholder='Review name'
            />
            <TextField
              value={review}
              onChange={this.handleInput('review')}
              placeholder='Review'
            />
            <Button onClick={this.handleReviewAdd}>Добавить отзыв</Button>
          </form>
        ) : (
          'Чтобы оставить отзыв необходимо войти в систему'
        )}
      </Paper>
    );
  }
}

export default withStyles(styles)(ReviewForm);
