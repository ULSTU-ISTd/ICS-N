import GameTab from './component/GameTab';

export default GameTab;