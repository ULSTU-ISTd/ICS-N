﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using UnityEngine;

namespace Chess
{
    class Moves
    {
        FigureMoving fm;
        Board board;

        public Moves(Board board)
        {
            this.board = board;
        }

        public bool CanMove(FigureMoving fm)
        {
            this.fm = fm;
            return
                CanMovefrom() &&//можно ли пойти с данной клетки
                CanMoveTo() &&//можно ли пойти на клетку
                CanFigureMove();//можно ли пойти данной фигурой
        }

        bool CanMovefrom()
        {
            return fm.from.OnBoard() &&
                fm.figure.GetColor() == board.moveColor;//фигура которой ходит д.б нужного цвета
        }

        bool CanMoveTo()
        {
            return fm.to.OnBoard() &&
                fm.from != fm.to &&
                board.GetFigureAt(fm.to).GetColor() != board.moveColor;//нельзя есть свои фигуры
        }

        bool CanFigureMove()
        {
            switch (fm.figure)
            {
                case Figure.whiteKing:
                case Figure.blackKing:
                    return CanKingMove();

                case Figure.whiteQueen:
                case Figure.blackQueen:
                    return CanStraightMove();

                case Figure.whiteRook:
                case Figure.blackRook:
                    return (fm.SignX == 0 || fm.SignY == 0) && //гориз или вертикально
                        CanStraightMove();

                case Figure.whiteBishop:
                case Figure.blackBishop:
                    return (fm.SignX != 0 && fm.SignY != 0) &&//по диагонали
                        CanStraightMove();

                case Figure.whiteKnight:
                case Figure.blackKnight:
                    return CanKhightMove();

                case Figure.whitePawn:
                case Figure.blackPawn:
                    return CanPawnMove();

                default: return false;
            }
        }

        bool CanPawnMove()
        {
            if (fm.from.y < 1 || fm.from.y > 6)
                return false;
            int stepY = fm.figure.GetColor() == Color.white ? 1 : -1;//вверх или вниз
            return CanPawnGo(stepY) ||
                   CanPawnGump(stepY) ||
                   CanPawnEat(stepY);
        }

        private bool CanPawnEat(int stepY)
        {
            if (board.GetFigureAt(fm.to) != Figure.none)
                if (fm.AbsDeltaY == 1)
                    if (fm.DeltaY == stepY)
                        return true;
            return false;
        }

        private bool CanPawnGump(int stepY)//может пойти на две клетки
        {
            if (board.GetFigureAt(fm.to) == Figure.none)
                if (fm.DeltaX == 0)
                    if (fm.DeltaY == 2 * stepY) //обязательно перепрыгнуть
                        if (fm.from.y == 1 || fm.from.y == 6)
                            if (board.GetFigureAt(new Square(fm.from.x, fm.from.y + stepY)) == Figure.none) //не перепрыгивает какую нибудь фигуру
                                return true;
            return false;                 
        }

        private bool CanPawnGo(int stepY)//просто идти
        {
            if (board.GetFigureAt(fm.to) == Figure.none) //клетка куда она идет пустая
                if (fm.DeltaX == 0) //идет прямо
                    if (fm.DeltaY == stepY) //идет только на один шаг
                        return true;
            return false;
        }

        //может двигаться прямо в любую сторону
        private bool CanStraightMove()
        {
            Square at = fm.from; // квадрат откуда мы начинаем двигаться
            do
            {
                at = new Square(at.x + fm.SignX, at.y + fm.SignY);
                if (at == fm.to)
                    return true;
            } while (at.OnBoard() &&
                     board.GetFigureAt(at) == Figure.none);
            return false;
        }

        private bool CanKingMove()
        {
            if (fm.AbsDeltaX <= 1 && fm.AbsDeltaY <= 1)
                return true;
            return false;
        }

        private bool CanKhightMove()
        {
            if (fm.AbsDeltaX == 1 && fm.AbsDeltaY == 2) return true;
            if (fm.AbsDeltaX == 2 && fm.AbsDeltaY == 1) return true;
            return false;
        }
    }
}
