<?php

    session_start();
	include("/functions/functions.php");
	$sorting = $_GET["sort"];
	switch($sorting)
	{
		case 'no-sort';
		$sorting = 'product_id DESC';
		$sort_name = 'Нет сортировки';
		break;
		
		case 'price-up';
		$sorting = 'price ASC';
		$sort_name = 'По возрастанию';
		break;
		
		case 'price-down';
		$sorting = 'price DESC';
		$sort_name = 'По убыванию';
		break;
		
		case 'new';
		$sorting = 'datetime DESC';
		$sort_name = 'Новинки';
		break;
		
		case 'popular';
		$sorting = 'count';
		$sort_name = 'Популярное DESC';
		break;
		
		default:
		$sorting = 'product_id DESC';
		$sort_name = 'Нет сортировки';
		break;
		
	}
	
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Интернет-магазин</title>
<link rel="stylesheet" href="/css/style.css">

    <script type="text/javascript" src="/js/jquery-1.8.2.min.js"></script> 
    <script type="text/javascript" src="/js/jcarousellite_1.0.1.js"></script> 
    <script type="text/javascript" src="/js/shop-script.js"></script>
    <script type="text/javascript" src="/js/jquery.cookie.min.js"></script>

    
    <script type="text/javascript" src="/js/jquery.form.js"></script>
    <script type="text/javascript" src="/js/jquery.validate.js"></script>  
    <script type="text/javascript" src="/js/TextChange.js"></script>  
</head>
<body>
<?php
	include("/include/db_connect.php");
	include("/include/block-header.php");
?>
	
	<div class="block-center">
		<div class="centercont">
			<?php
				include("/include/menu-left.php");
			?>
			<div class="block-content">	
				<div class="block-top-center">
					<ul class="center-name-page">
						<li class="center-name-item"><a href="index.php">Без сортировки</a></li>
						<li class="center-name-item"><a href="index.php?sort=price-up">По возрастанию</a></li>
						<li class="center-name-item"><a href="index.php?sort=price-down">По убыванию</a></li>
						<li class="center-name-item"><a href="index.php?sort=new">Новинки</a></li>
						<li class="center-name-item"><a href="index.php?sort=popular">Популярное</a></li>
						<li>Текущая сортировка: <?php echo $sort_name; ?></li>
					</ul>
				</div>
				<div class="center-sort-product"></div>
			<?php
				
				$num = 9;
				$page = (int)$_GET['page'];
				
				$count = mysql_query("SELECT COUNT(*) FROM table_products WHERE visible = '1'",$link);
				$temp = mysql_fetch_array($count);
				if ($temp[0] > 0)
				{
					$tempcount = $temp[0];
					
					$total = (($tempcount - 1) / $num)+ 1;
					$total = intval($total);
					
					$page = intval($page);
					
					if(empty($page) or $page<0) $page = 1;
					if($page > $total) $page = $total;
					
					$start = $page * $num - $num;
					
					$qury_start_num = " LIMIT $start, $num";
				}
				
				$result = mysql_query("SELECT * FROM table_products ORDER BY $sorting $qury_start_num",$link);
				
				if (mysql_num_rows($result) > 0)
				{
					$row = mysql_fetch_array($result);
					
					
					
					do
					{
						if  (strlen($row["image"]) > 0 && file_exists("./product_img/".$row["image"]))
{
$img_path = './product_img/'.$row["image"];
$max_width = 280; 
$max_height = 280; 
 list($width, $height) = getimagesize($img_path); 
$ratioh = $max_height/$height; 
$ratiow = $max_width/$width; 
$ratio = min($ratioh, $ratiow); 
 
$width = intval($ratio*$width); 
$height = intval($ratio*$height);    
}else
{
$img_path = "/images/noimages.jpeg";
$width = 150;
$height = 125;
} 
						echo '
						<a href="product.php?id='.$row["product_id"].'" class="color-href">
						<div class="block-product">
						<div class="block-product-img" align="center">
						<img src="'.$img_path.'" width="'.$width.'" height="'.$height.'" />
						</div>
						<div class="block-descrip-product">
						<p class="title-product">'.$row["title"].'</p>
						<div class="block-price-cart">
						<p class="price">'.group_numerals($row["price"]).'<a class="price_valiut">р.</a></p><a tid="'.$row["product_id"].'" class="cart-button"><img src="/img/carts.png" width="110" height="35"></a>
						</div>
						</div>
						</div>
						</a>
						';
						
						
						
					}
					while ($row = mysql_fetch_array($result));

				}
				if ($page != 1){ $pstr_prev = '<li><a class="pstr-prev" href="index.php?page='.($page - 1).'">&lt;</a></li>';}
				if ($page != $total) $pstr_next = '<li><a class="pstr-next" href="index.php?page='.($page + 1).'">&gt;</a></li>';

													
				// Формируем ссылки со страницами
				if($page - 5 > 0) $page5left = '<li><a href="index.php?page='.($page - 5).'">'.($page - 5).'</a></li>';
				if($page - 4 > 0) $page4left = '<li><a href="index.php?page='.($page - 4).'">'.($page - 4).'</a></li>';
				if($page - 3 > 0) $page3left = '<li><a href="index.php?page='.($page - 3).'">'.($page - 3).'</a></li>';
				if($page - 2 > 0) $page2left = '<li><a href="index.php?page='.($page - 2).'">'.($page - 2).'</a></li>';
				if($page - 1 > 0) $page1left = '<li><a href="index.php?page='.($page - 1).'">'.($page - 1).'</a></li>';

				if($page + 5 <= $total) $page5right = '<li><a href="index.php?page='.($page + 5).'">'.($page + 5).'</a></li>';
				if($page + 4 <= $total) $page4right = '<li><a href="index.php?page='.($page + 4).'">'.($page + 4).'</a></li>';
				if($page + 3 <= $total) $page3right = '<li><a href="index.php?page='.($page + 3).'">'.($page + 3).'</a></li>';
				if($page + 2 <= $total) $page2right = '<li><a href="index.php?page='.($page + 2).'">'.($page + 2).'</a></li>';
				if($page + 1 <= $total) $page1right = '<li><a href="index.php?page='.($page + 1).'">'.($page + 1).'</a></li>';

				if ($page+5 < $total)
				{
					$strtotal = '<li><p class="nav-point">...</p></li><li><a href="index.php?page='.$total.'">'.$total.'</a></li>';
				}else
				{
					$strtotal = ""; 
				}

				if ($total > 1)
				{
					echo '
					<div class="pstrnav">
					<ul>
					';
					echo $pstr_prev.$page5left.$page4left.$page3left.$page2left.$page1left."<li><a class='pstr-active' href='index.php?page=".$page."'>".$page."</a></li>".$page1right.$page2right.$page3right.$page4right.$page5right.$strtotal.$pstr_next;
					echo '
					</ul>
					</div>
					';
				}﻿
				
			?>
			</div>
			</div>
		</div>
	</div>

	
	
<?php
	include("/include/block-footer.php");
?>
</body>
</html>