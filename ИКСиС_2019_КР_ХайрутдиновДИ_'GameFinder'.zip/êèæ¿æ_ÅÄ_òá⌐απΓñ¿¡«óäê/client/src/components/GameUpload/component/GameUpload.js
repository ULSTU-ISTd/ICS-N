import React from 'react';

import Clear from '@material-ui/icons/Clear';
import { withStyles } from '@material-ui/core/styles';

import UploadForm from 'components/UploadForm';
import styles from './styles';

const GameUpload = ({ classes, hideGameUpload }) => (
  <div className={classes.overlay}>
    <Clear className={classes.overlayCloser} onClick={hideGameUpload}></Clear>
    <UploadForm closeForm={hideGameUpload}/>
  </div>
);

export default withStyles(styles)(GameUpload);
