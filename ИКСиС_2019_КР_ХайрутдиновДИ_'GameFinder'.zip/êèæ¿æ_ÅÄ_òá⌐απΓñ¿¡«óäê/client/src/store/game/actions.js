import apiClient from 'utils/apiClient';
import {
  GET_GAMES,
  GET_GAMES_SUCCESS,
  GET_GAMES_FAIL,
  ADD_GAME,
  ADD_GAME_SUCCESS,
  ADD_GAME_FAIL,
  UPDATE_GAME_RATING,
  REMOVE_REVIEW,
  REMOVE_REVIEW_SUCCESS,
  REMOVE_REVIEW_ERROR,
  UPDATE_GAME_RATING_SUCCESS,
  UPDATE_GAME_RATING_ERROR,
  CHANGE_CURRENT_GAME
} from 'store/game/constants';

function getFormData(dataObject) {
  const formData = new FormData();

  Object.keys(dataObject).forEach(key => {
    formData.append(key, dataObject[key]);
  });

  return formData;
}

export function getGames() {
  return dispatch => {
    dispatch({ type: GET_GAMES });

    apiClient.get('games').then(({ data, error }) => {
      if (error) {
        dispatch({ type: GET_GAMES_FAIL });
        return;
      }

      const { games } = data;

      dispatch({ type: GET_GAMES_SUCCESS, games });
    });
  };
}

export function addGame(game, selectedCategory, description, publisher, image) {
  return dispatch => {
    dispatch({ type: ADD_GAME });

    const formData = getFormData({
      name: game,
      category: selectedCategory,
      description,
      publisher,
      image
    });

    apiClient.post('games', formData).then(({ data, error }) => {
      if (error) {
        dispatch({ type: ADD_GAME_FAIL });
        return;
      }

      const { game } = data;
      dispatch({ type: ADD_GAME_SUCCESS, game });
    });
  };
}

export function updateGameRating(gameId, direction) {
  return dispatch => {
    dispatch({ type: UPDATE_GAME_RATING });

    apiClient
      .post(`games/update/${gameId}`, { direction })
      .then(({ data, error }) => {
        if (error) {
          dispatch({ type: UPDATE_GAME_RATING_ERROR });
          return;
        }

        dispatch({
          type: UPDATE_GAME_RATING_SUCCESS,
          payload: { gameId, direction }
        });
      });
  };
}

export function changeCurrentGame(gameId) {
  return dispatch => dispatch({ type: CHANGE_CURRENT_GAME, gameId });
}

export function removeReview(reviewId) {
  return dispatch => {
    dispatch({ type: REMOVE_REVIEW });

    apiClient.post(`reviews/delete/${reviewId}`).then(({ data, error }) => {
      if (error) {
        dispatch({ type: REMOVE_REVIEW_ERROR });
        return;
      }
      dispatch({
        type: REMOVE_REVIEW_SUCCESS,
        payload: { reviewId }
      });
    });
  };
}
