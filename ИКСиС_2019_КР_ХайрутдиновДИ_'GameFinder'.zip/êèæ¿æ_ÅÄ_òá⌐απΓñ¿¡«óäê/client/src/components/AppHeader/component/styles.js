import { DARK_GREEN, LIGHT_GREEN } from 'styles/colors';

const styles = () => ({
  header: {
    position: 'relative',
    flexDirection: 'row',
    justifyContent: 'space-between',
    height: 60,
    background: DARK_GREEN,
  },
  nav: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    paddingLeft: 13
  },
  navButton: {
    margin: '0px 5px',
    color: LIGHT_GREEN,
    transition: 'all .5s ease',
    '&:hover': {
      color: DARK_GREEN,
      background: LIGHT_GREEN
    }
  }
});

export default styles;
